 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.rule;


import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.builder.model.KieBaseModel;
import org.kie.api.builder.model.KieModuleModel;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.batch.item.ExecutionContext;

@Slf4j
public class RuleEngine {
    public final static String SHOULD_STOP = "shouldStop";

    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    private final KieServices kieServices;

    private KieContainer kieContainer;

    public RuleEngine() {
        this.kieServices = KieServices.Factory.get();
    }

    public void updateRules(List<String> rules) {
        lock.writeLock().lock();
        try {
            KieModuleModel kieModuleModel = kieServices.newKieModuleModel();
            KieBaseModel kieBaseModel = kieModuleModel.newKieBaseModel("KBase")
                    .setDefault(true)
                    .setEventProcessingMode(org.kie.api.conf.EventProcessingOption.STREAM); // Optional, depending on
            // use case
            kieBaseModel.newKieSessionModel("KSession").setDefault(true);

            // Create a new KieFileSystem in memory
            KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
            kieFileSystem.writeKModuleXML(kieModuleModel.toXML());

            for (int i = 0; i < rules.size(); i++) {
                String ruleName = "Rule_" + i;
                String ruleContent = rules.get(i);

                // Write each rule string as a DRL into the in-memory KieFileSystem
                String path = "src/main/resources/rules/" + ruleName + ".drl"; // Path for KieFileSystem's virtual FS
                kieFileSystem.write(path, ruleContent); // Write rule string
            }

            KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem);
            kieBuilder.buildAll();

            // Check for errors in rule compilation
            if (kieBuilder.getResults().hasMessages(Message.Level.ERROR)) {
                log.error("Errors during rule compilation: {}", kieBuilder.getResults().getMessages());
                throw new RuntimeException("Error compiling rules: " + kieBuilder.getResults().getMessages());
            }

            // Create a new KieContainer
            kieContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void fireRules(List<?> facts, ExecutionContext context) {
        lock.readLock().lock();
        try {
            if (kieContainer == null) {
                throw new IllegalStateException("Rules have not been initialized. Call updateRules() first.");
            }

            KieSession kieSession = kieContainer.newKieSession();
            // ToDo: context -> session global
            try {
                for (Object fact : facts) {
                    kieSession.insert(fact);
                }
                kieSession.fireAllRules();

            } finally {
                kieSession.dispose(); // Clean up session
            }
        } finally {
            lock.readLock().unlock();
        }
    }

    public boolean fireRulesShouldStop(List<?> facts, ExecutionContext context, boolean stopOnError) {
        lock.readLock().lock();
        Boolean stop = false;
        try {
            if (kieContainer == null) {
                throw new IllegalStateException("Rules have not been initialized. Call updateRules() first.");
            }

            KieSession kieSession = kieContainer.newKieSession();
            // ToDo: context -> session global
            try {
                for (Object fact : facts) {
                    kieSession.insert(fact);
                    kieSession.fireAllRules();
                    AtomicBoolean shouldStop = (AtomicBoolean) kieSession.getGlobal(SHOULD_STOP);
                    if (stopOnError && shouldStop.get()) {
                        stop = true;
                        break;
                    }
                }
            } finally {
                kieSession.dispose(); // Clean up session
            }
        } finally {
            lock.readLock().unlock();
        }

        return stop;
    }
}
