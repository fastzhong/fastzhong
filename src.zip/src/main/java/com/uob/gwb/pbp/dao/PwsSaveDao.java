 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.dao;


import com.uob.gwb.pbp.po.*;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("pwsSaveDao")
public interface PwsSaveDao {

    // bank ref
    int getBankRefSequenceNum();

    List<Integer> getBatchBankRefSequenceNum(int count);

    // payment transaction main tables
    int insertPwsTransactions(@Param("pwsTransactions") PwsTransactions pwsTransactions);

    int insertPwsBulkTransactions(@Param("pwsBulkTransactions") PwsBulkTransactions pwsBulkTransactions);

    // child txn
    int insertPwsBulkTransactionInstructions(
            @Param("pwsBulkTransactionInstructions") PwsBulkTransactionInstructions pwsBulkTransactionInstructions);

    // parties
    int insertPwsParties(@Param("pwsParties") PwsParties pwsParties);

    int insertPwsPartyContacts(@Param("pwsPartyContacts") PwsPartyContacts pwsPartyContacts);

    // additional info
    int insertPwsTransactionAdvices(@Param("pwsTransactionAdvices") PwsTransactionAdvices pwsTransactionAdvices);

    int insertPwsTaxInstructions(@Param("pwsTaxInstructions") PwsTaxInstructions pwsTaxInstructions);

    // cew supporting tables
    int insertPwsTransitMessage(@Param("pwsTransitMessage") PwsTransitMessage pwsTransitMessage);

}
