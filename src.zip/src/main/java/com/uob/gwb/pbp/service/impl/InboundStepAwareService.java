 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.*;
import com.uob.gwb.pbp.bo.validation.RejectOnErrorConfig;
import com.uob.gwb.pbp.config.BulkRoutesConfig;
import com.uob.gwb.pbp.flow.ContextKey;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.po.PwsFileUpload;
import com.uob.gwb.pbp.po.PwsTransitMessage;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

public abstract class InboundStepAwareService {

    protected StepExecution stepExecution;

    public void beforeStep(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    public void afterStep(StepExecution stepExecution) {
        // ToDo: Subclasses can optionally override this method
    }

    // execution
    protected JobExecution getJobExecution() {
        return stepExecution.getJobExecution();
    }

    protected ExecutionContext getJobContext() {
        return stepExecution.getJobExecution().getExecutionContext();
    }

    protected StepExecution getStepExecution() {
        return this.stepExecution;
    }

    protected ExecutionContext getStepContext() {
        return stepExecution.getExecutionContext();
    }

    // context
    protected String getRouteName() {
        return getRouteConfig().getRouteName();
    }

    protected BulkRoutesConfig.BulkRoute getRouteConfig() {
        return getJobContext().get(ContextKey.routeConfig, BulkRoutesConfig.BulkRoute.class);
    }

    protected String getCountryCode() {
        return getJobContext().get(ContextKey.country, Country.class).getCountryCode();
    }

    protected String getChannel() {
        return getJobContext().get(ContextKey.channel, Channel.class).name();
    }

    protected String getBankEntityId() {
        return getJobContext().get(ContextKey.bankEntity, BankEntity.class).getId();
    }

    protected String getSourcePath() {
        return getJobContext().getString(ContextKey.sourcePath);
    }

    protected String getSourceName() {
        return getJobContext().getString(ContextKey.sourceName);
    }

    protected SourceFormat getSourceFormat() {
        return getJobContext().get(ContextKey.sourceFormat, SourceFormat.class);
    }

    protected void setSourceFormat(SourceFormat sourceFormat) {
        getStepContext().put(ContextKey.sourceFormat, sourceFormat);
    }

    protected Pain001InboundProcessingResult getResult() {
        return getJobContext().get(ContextKey.result, Pain001InboundProcessingResult.class);
    }

    protected RejectOnErrorConfig getRejectOnError() {
        return getJobContext().get(ContextKey.rejectOnError, RejectOnErrorConfig.class);
    }

    protected void setRejectOnError(RejectOnErrorConfig setting) {
        getJobContext().put(ContextKey.rejectOnError, setting);
    }

    protected void setBankRefMetaData(BankRefMetaData bankRefMetaData) {
        getJobContext().put(ContextKey.bankRefMetaData, bankRefMetaData);
    }

    protected BankRefMetaData getBankRefMetadata() {
        return getJobContext().get(ContextKey.bankRefMetaData, BankRefMetaData.class);
    }

    protected PwsFileUpload getFileUpload() {
        return getStepContext().get(ContextKey.fileUpload, PwsFileUpload.class);
    }

    protected void setFileUpload(PwsFileUpload fileUpload) {
        getStepContext().put(ContextKey.fileUpload, fileUpload);
    }

    protected PwsTransitMessage getTransitMessage() {
        return getStepContext().get(ContextKey.transitMessage, PwsTransitMessage.class);
    }

    protected void setTransitMessage(PwsTransitMessage pwsTransitMessage) {
        getStepContext().put(ContextKey.transitMessage, pwsTransitMessage);
    }

}
