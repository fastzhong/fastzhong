 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.data.mapper.Pain001ToBoMapper;
import com.uob.gwb.pbp.iso.pain001.GroupHeaderDTO;
import com.uob.gwb.pbp.iso.pain001.Pain001;
import com.uob.gwb.pbp.iso.pain001.PaymentInformationDTO;
import com.uob.gwb.pbp.service.PaymentMappingService;
import com.uob.gwb.pbp.util.CommonUtils;
import java.text.ParseException;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Slf4j
@Component
public class PaymentMappingServiceImpl extends StepAwareService implements PaymentMappingService {

    private final Pain001ToBoMapper pain001ToBoMapper;

    public PaymentInformation pain001PaymentToBo(PaymentInformationDTO paymentDTO) {
        return pain001ToBoMapper.mapToPaymentInformation(paymentDTO);
    }

    @Override
    public List<PaymentInformation> postMappingPain001ToBo(Pain001 pain001, List<PaymentInformation> paymentInfos) {

        // ToDo: https://confluencep.sg.uobnet.com/display/GBTCEW/BFU+Mapping+Overview

        // 19
        // CustomerBulkReference
        // Generate this value at CEW and save customerCreditTransferInitiation.paymentInformation.paymentInformationIdentification
        // PWS_TRANSACTIONS_INSTRUCTIONS.CUSTOMER_REFERENCE or PWS_TRANSACTIONS.BANK_REFERENCE_ID

        // 25
        // debtorName Debtor Name: DMP will provide? Initiator Company Name
        // customerCreditTransferInitiation.paymentInformation.debtor.name
        // get from v3 api - Company Abbreviated name

        // 39
        // bicfi
        // customerCreditTransferInitiation.paymentInformation.debtorAgent.financialInstitutionIdentification.BICFI
        // Not Clear yet Only Applicable for Bahtnet


        // rejected txn
        // 48
        // errordescription	Cutomize	DMP generated
        // paymentInformation.creditTransferTransactionInformation.errordescription
        // PWS_REJECTED_RECORD.ERROR_DETAIL
        //
        // 49
        // linenumber	Cutomize	To send Row number for each txn
        // customerCreditTransferInitiation.paymentInformation.creditTransferTransactionInformation.linenumber
        // PWS_REJECTED_RECORD.ERROR_DETAIL.LINE_NUMBER

        // 58
        // charge Bearer	"BEN" or "OUR"(Beneficiary or Debtor)
        // customerCreditTransferInitiation.paymentInformation.creditTransferTransactionInformation.chargeBearer
        // PWS_TRANSACTION_INSTRUCTIONS.CHARGE_BORNE_BY

        // 63 vs 66
        // Customer Input vs branch name
        // creditTransferTransactionInformation.creditorAgent.financialInstitutionIdentification.name
        // creditTransferTransactionInformation.creditorAgent.branchIdentification.name
        // PWS_TRANSACTION_INSTRUCTIONS.DESTINATION_BANK_NAME

        // 82
        // identification	Customer Input creditor identification
        // customerCreditTransferInitiation.paymentInformation.creditTransferTransactionInformation.creditor.identification.organisationIdentification.other.identification
        // PWS_TRANSACTION_ADVICES.ADVICE_ID

        // 83 & 85
        // PWS_TRANSACTION_ADVICES.PARTY_NAME2

        // 88-91
        // PWS_TAX_INSTRUCTIONS.TAX_DOCUMENT_NUMBER

        // 92 vs 100
        // PWS_TAX_INSTRUCTIONS.TAXABLE_AMOUNT

        // 99 tax rate
        // customerCreditTransferInitiation.paymentInformation.creditTransferTransactionInformation.tax.record.taxAmount.rate PWS_TAX_INSTRUCTIONS.TAX_RATE_IN_PERCENTAGE

        GroupHeaderDTO groupHeaderDTO = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getGroupHeader();
        try {
            for (int i = 0; i< paymentInfos.size(); i++){
                PaymentInformation paymentInfo = paymentInfos.get(i);
                PaymentInformationDTO paymentInformationDTO = pain001.getBusinessDocument().getCustomerCreditTransferInitiation().getPaymentInformation().get(i);
                paymentInfo.getPwsBulkTransactions().setTransferDate(CommonUtils.stringToDate(groupHeaderDTO.getCreationDateTime()));

                // child txn
                for (int j=0; j< paymentInfo.getCreditTransferTransactionList().size(); j++) {
                    CreditTransferTransaction txn = paymentInfo.getCreditTransferTransactionList().get(j);
                    txn.getPwsBulkTransactionInstructions().setOriginalValueDate(CommonUtils.stringToTimestamp(paymentInformationDTO.getRequestedExecutionDate().getDate()));
                }
            }
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }

        return paymentInfos;
    }
}
