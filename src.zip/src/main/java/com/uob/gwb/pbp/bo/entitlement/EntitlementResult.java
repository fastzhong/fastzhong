package com.uob.gwb.pbp.bo.entitlement;

public enum EntitlementResult {

    APPROVED, REJECTED;

}
