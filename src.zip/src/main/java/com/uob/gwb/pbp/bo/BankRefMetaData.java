 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.bo;


import lombok.Data;

@Data
public class BankRefMetaData {

    public static final String BANK_REF_ID_FORMAT = "%06d";

    private final String countryCode;
    private final String channelPrefix;
    private final String reqPrefix;
    private final String yymm;

    public String generateBankRefId(int seqNo) {
        int seqLengthData = 1000000;
        String sequenceStarter = null;
        int quotient = seqNo / seqLengthData; // will drive logic for x
        int remainder = seqNo % seqLengthData; // 6 digit sequence
        // case when quotient is less than 9 keep sequence like 0,1,2,3....9
        if (quotient <= 9)
            sequenceStarter = Integer.toString(quotient);
        // if quotient is greater than 9 for perticular month in that case start X value
        // with A
        // A, B,C, D.....Z
        else {
            int ch = 97;
            int quotientCh = ch + (quotient - 10);
            char quotientCharacter = (char) quotientCh;
            sequenceStarter = Character.toString(quotientCharacter).toUpperCase();
        }
        return countryCode + channelPrefix + reqPrefix + sequenceStarter + yymm
                + String.format(BANK_REF_ID_FORMAT, remainder);
    }
}
