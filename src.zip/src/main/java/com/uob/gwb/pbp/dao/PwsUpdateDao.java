package com.uob.gwb.pbp.dao;

import org.springframework.stereotype.Repository;

@Repository("pwsUpdateDao")
public interface PwsUpdateDao {
}
