 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.validation.TransactionValidationRecord;
import com.uob.gwb.pbp.rule.DecisionMatrixRow;
import com.uob.gwb.pbp.rule.GenericRuleTemplate;
import com.uob.gwb.pbp.rule.RuleEngine;
import com.uob.gwb.pbp.service.DecisionMatrixService;
import java.util.List;
import java.util.stream.Collectors;

import com.uob.gwb.pbp.service.TransactionValidationHelper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("transactionDecisionMatrixService")
public class TransactionDecisionMatrixServiceImpl implements DecisionMatrixService<TransactionValidationRecord> {

    private final GenericRuleTemplate ruleTemplate;
    private final TransactionValidationHelper txnValidationHelper;
    private final RuleEngine ruleEngine;

    @Override
    public void updateRules(List<DecisionMatrixRow> decisionMatrix) {
        List<String> rules = decisionMatrix.stream().map(ruleTemplate::generateRule).collect(Collectors.toList());
        ruleEngine.updateRules(rules);
    }

    @Override
    public void applyRules(List<TransactionValidationRecord> txnValidationRecords, ExecutionContext context) {
        ruleEngine.fireRules(txnValidationRecords, context);
    }

    @Override
    public boolean applyRulesShouldStop(List<TransactionValidationRecord> txnValidationRecords,
            ExecutionContext context, boolean stopOnError) {
        return ruleEngine.fireRulesShouldStop(txnValidationRecords, context, stopOnError);
    }

}
