 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.bo;

public enum Channel
{

    IDB("I"), API("A"), FileACT("F"), H2H("H"), RFTS("R");

    public final String prefix;

    private Channel(String prefix) {
        this.prefix = prefix;
    }
}
