 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.iso.pain001;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class GroupHeaderDTO {
    @JsonProperty("filereference")
    private String filereference;
    @JsonProperty("originalfilename")
    private String originalfilename;
    @JsonProperty("channel")
    private String channel;
    @JsonProperty("fileformat")
    private String fileformat;
    @JsonProperty("filestatus")
    private String filestatus;
    @JsonProperty("errordescription")
    private List<?> errordescription;
    @JsonProperty("channelid")
    private String channelid;
    @JsonProperty("messageIdentification")
    private String messageIdentification;
    @JsonProperty("creationDateTime")
    private String creationDateTime;
    @JsonProperty("numberOfTransactions")
    private String numberOfTransactions;
    private String controlSum;
    @JsonProperty("initiatingParty")
    private InitiatingPartyDTO initiatingParty;
}
