 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import java.sql.Date;
import lombok.Data;

@Data
public class PwsBulkTransactions {

    private Long bkTransactionId;

    private Long transactionId;

    private Long fileUploadId;

    private String recipientsReference;

    private String recipientsDescription;

    private String fateFileName;

    private String fateFilePath;

    private String combineDebit;

    private String status;

    private Long changeToken;

    private String errorDetail;

    private Date finalFateUpdatedDate;

    private String ackFilePath;

    private Date ackUpdatedDate;

    private Date transferDate;

    private String userComments;

    private String dmpBatchNumber;

    private String rejectCode;

    private String batchBooking;

    private String chargeOptions;

    private String payrollOptions;

}
