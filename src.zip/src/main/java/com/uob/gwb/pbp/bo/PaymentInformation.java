 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.bo;


import com.uob.gwb.pbp.bo.status.DmpBulkStatus;
import com.uob.gwb.pbp.bo.validation.DuplicateValidationResult;
import com.uob.gwb.pbp.bo.validation.EntitlementValidationResult;
import com.uob.gwb.pbp.bo.validation.PaymentValidationResult;
import com.uob.gwb.pbp.po.PwsBulkTransactions;
import com.uob.gwb.pbp.po.PwsTransactions;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class PaymentInformation {

    DmpBulkStatus dmpBulkStatus;

    // validation
    EntitlementValidationResult entitlementValidationResult;
    List<PaymentValidationResult> paymentValidationResults = new ArrayList<>();
    DuplicateValidationResult duplicateValidationResult;

    // POs
    PwsTransactions pwsTransactions;
    PwsBulkTransactions pwsBulkTransactions;

    // transactions
    List<CreditTransferTransaction> creditTransferTransactionList;

    public void addValidationError(String errorCode, String errorMsg) {
        paymentValidationResults.add(new PaymentValidationResult(errorCode, errorMsg));
    }

    public boolean isValid() {

        if (DmpBulkStatus.REJECTED.equals(dmpBulkStatus)) {
            return false;
        }

        if (!EntitlementValidationResult.Result.SUCCESS.equals(entitlementValidationResult.getResult())) {
            return false;
        }

        if (!paymentValidationResults.isEmpty()) {
            return false;
        }

        return DuplicateValidationResult.False.equals(duplicateValidationResult);

    }

    public boolean isAllChildTranactionsValid() {
        for (CreditTransferTransaction txn : creditTransferTransactionList) {
            if (!txn.isValid()) {
                return false;
            }
        }
        return true;
    }

    public int getTotalValidTransactions() {
        int totalValid = 0;
        for (CreditTransferTransaction txn : creditTransferTransactionList) {
            if (txn.isValid()) {
                totalValid += 1;
            }
        }
        return totalValid;
    }

}
