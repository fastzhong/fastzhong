 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.flow;


import com.uob.ufw.core.exception.ApplicationException;

public class BulkProcessingException extends ApplicationException {

    private static final String ERROR_CODE = "CEW-bulk-processing-general-error";

    public BulkProcessingException(String message, Throwable cause) {
        this(ERROR_CODE, message, cause);
    }

    public BulkProcessingException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }

}
