package com.uob.gwb.pbp.bo.status;

public enum BulkProcessingStatus {

    DmpRejected,
    CewRejected, // REJECTED ON FILE ERROR

    // 1. validateJson
    Received,
    Processing,
    // 2. debulk
    Debulked,
    // 3. entitlement & validation
    EntitlelmentPassed,
    EntitlementWithException,
    ValidationPassed,
    ValidationWithException,
    // 4. enrichment
    EnrichmentPassed,
    // 5. Save
    SavePassed,
    SaveWithException;


}
