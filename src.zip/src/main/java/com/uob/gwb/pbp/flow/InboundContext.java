 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.flow;


import com.uob.gwb.pbp.config.BulkRoutesConfig;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InboundContext {

    BulkRoutesConfig.RouteConfig routeConfig;

    String sourcePath;
    String sourceName;
    String sourceStatus;
    String format;
    String content;
    Long start;
    Long end;

    Pain001InboundProcessingResult pain001InboundProcessingResult;
    String errorMsg;

    @Override
    public String toString() {
        return "InboundContext{" + "routeConfig=" + routeConfig + ", sourcePath='" + sourcePath + '\''
                + ", sourceName='" + sourceName + '\'' + ", sourceStatus='" + sourceStatus + '\'' + ", format='"
                + format + '\'' + ", start='"
                + LocalDateTime.ofInstant(Instant.ofEpochMilli(start), ZoneId.systemDefault()) + '\'' + ", end="
                + LocalDateTime.ofInstant(Instant.ofEpochMilli(end), ZoneId.systemDefault()) + '\''
                + ", pain001InboundProcessingResult=" + pain001InboundProcessingResult + ", errorMsg='" + errorMsg
                + '\'' + '}';
    }
}
