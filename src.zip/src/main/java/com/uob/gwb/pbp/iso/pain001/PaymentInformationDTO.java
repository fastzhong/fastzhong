 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.iso.pain001;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class PaymentInformationDTO {
    @JsonProperty("DMPBatchRef")
    private String dMPBatchRef;
    @JsonProperty("product")
    private String product;
    @JsonProperty("productfeature")
    private String productfeature;
    @JsonProperty("bulkstatus")
    private String bulkstatus;
    @JsonProperty("errordescription")
    private List<?> errordescription;
    @JsonProperty("numberOfTransactions")
    private String numberOfTransactions;
    @JsonProperty("controlSum")
    private String controlSum;
    @JsonProperty("requestedExecutionDate")
    private RequestedExecutionDateDTO requestedExecutionDate;
    @JsonProperty("debtor")
    private DebtorDTO debtor;
    @JsonProperty("debtorAccount")
    private DebtorAccountDTO debtorAccount;
    @JsonProperty("debtorAgent")
    private DebtorAgentDTO debtorAgent;
    @JsonProperty("chargesAccount")
    private ChargesAccountDTO chargesAccount;
    @JsonProperty("creditTransferTransactionInformation")
    private List<CreditTransferTransactionInformationDTO> creditTransferTransactionInformation;
}
