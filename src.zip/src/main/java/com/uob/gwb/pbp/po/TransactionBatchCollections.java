 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class TransactionBatchCollections {

    private final List<PwsBulkTransactionInstructions> txnInstructions = new ArrayList<>();
    private final List<PwsParties> parties = new ArrayList<>();
    private final List<List<PwsPartyContacts>> partyContacts = new ArrayList<>();
    private final List<PwsPartyBanks> partyBanks = new ArrayList<>();
    private final List<PwsTransactionAdvices> advices = new ArrayList<>();
    private final List<List<PwsTaxInstructions>> taxInstructions = new ArrayList<>();

}
