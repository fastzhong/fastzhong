 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import lombok.Data;

@Data
public class PwsPartyContacts {
    private long partyId;
    private String bankEntityId;
    private Long transactionId;
    private String bankReferenceId;
    private String childBankReferenceId;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String address5;

    private String phoneCountry;
    private String phoneNo;
    private String phoneCountryCode;
    // structured
    private String country;
    private String province;
    private String districtName;
    private String subDistrictName;
    private String streetName;
    private String townName;
    private String postalCode;
    private String buildingNumber;
    private String buildingName;
    private String floor;
    private String unitNumber;
    private String department;
    private Boolean isNew;
    private String partyContactType;
}
