 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.PaymentInformation;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("paymentDebulkServiceImplTH")
public class PaymentDebulkServiceImplTH extends PaymentDebulkServiceImpl {

    @Override
    public List<PaymentInformation> debulkPaymentInformations(List<PaymentInformation> paymentInfos) {
        // ToDo
        // resourceId = smart
        // amount <= 2M: smart-same-day
        // amount > 2M: bahtnet
        // amount ?
        return null;
    }
}
