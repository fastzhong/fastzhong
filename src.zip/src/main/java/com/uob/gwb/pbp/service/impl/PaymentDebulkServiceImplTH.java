 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.Resource;
import com.uob.gwb.pbp.bo.status.DmpBulkStatus;
import com.uob.gwb.pbp.config.AppConfig;
import com.uob.gwb.pbp.po.PwsTransactions;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("paymentDebulkServiceImplTH")
public class PaymentDebulkServiceImplTH extends PaymentDebulkServiceImpl {

    private final AppConfig appConfig;

    @Override
    public List<PaymentInformation> debulkPaymentInformations(List<PaymentInformation> paymentInfos) {
        List<PaymentInformation> debulkedPayments = new ArrayList<>();

        for (PaymentInformation paymentInfo : paymentInfos) {
            // Skip if payment info is invalid
            if (DmpBulkStatus.REJECTED.equals(paymentInfo.getDmpBulkStatus())) {
                debulkedPayments.add(paymentInfo);
                continue;
            }

            PwsTransactions pwsTransaction = paymentInfo.getPwsTransactions();

            // Skip if not SMART payment
            if (!Resource.SMART.id.equals(pwsTransaction.getResourceId())) {
                debulkedPayments.add(paymentInfo);
                continue;
            }

            // Process each child transaction
            List<CreditTransferTransaction> originalChildTxns = paymentInfo.getCreditTransferTransactionList();
            if (originalChildTxns != null) {
                Map<String, List<CreditTransferTransaction>> groupedTxns = new HashMap<>();

                // Group transactions based on amount threshold
                for (CreditTransferTransaction childTxn : originalChildTxns) {
                    BigDecimal txnAmount = childTxn.getPwsBulkTransactionInstructions().getTransactionAmount();
                    String targetResourceId = determineResourceId(txnAmount);
                    groupedTxns.computeIfAbsent(targetResourceId, k -> new ArrayList<>()).add(childTxn);
                }

                // Create new payment information for each group
                for (Map.Entry<String, List<CreditTransferTransaction>> entry : groupedTxns.entrySet()) {
                    String resourceId = entry.getKey();
                    List<CreditTransferTransaction> groupTxns = entry.getValue();

                    PaymentInformation newPaymentInfo = createNewPaymentInfo(paymentInfo, resourceId, groupTxns);
                    debulkedPayments.add(newPaymentInfo);
                }
            }
        }

        return debulkedPayments;
    }

    private String determineResourceId(BigDecimal amount) {
        // ToDo: bankCode = 024 smart -> ?
        // bankCode != 024
        if (amount.compareTo(appConfig.getDebulk().getBahtnetThreshold()) >= 0) {
            return Resource.BAHTNET.id;
        }
        return Resource.SMART_SAME_DAY.id;
    }

    private PaymentInformation createNewPaymentInfo(PaymentInformation originalPayment, String resourceId,
            List<CreditTransferTransaction> transactions) {

        PaymentInformation newPaymentInfo = new PaymentInformation();
        newPaymentInfo.setDmpBulkStatus(originalPayment.getDmpBulkStatus());

        // Copy bulk transaction details
        newPaymentInfo.setPwsBulkTransactions(originalPayment.getPwsBulkTransactions());

        // Create new PwsTransactions with updated details
        PwsTransactions originalPwsTxn = originalPayment.getPwsTransactions();
        PwsTransactions newPwsTxn = new PwsTransactions();
        // Copy all properties from original transaction
        BeanUtils.copyProperties(originalPwsTxn, newPwsTxn);
        // Update specific fields
        newPwsTxn.setResourceId(resourceId);
        // Set the new transactions
        newPaymentInfo.setPwsTransactions(newPwsTxn);
        newPaymentInfo.setCreditTransferTransactionList(transactions);

        return newPaymentInfo;
    }

}
