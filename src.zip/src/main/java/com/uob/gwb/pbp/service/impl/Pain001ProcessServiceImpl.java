 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;

import static com.uob.gwb.pbp.flow.SourceProcessStatus.*;

import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.DmpFileStatus;
import com.uob.gwb.pbp.flow.SourceProcessStatus;
import com.uob.gwb.pbp.iso.pain001.GroupHeaderDTO;
import com.uob.gwb.pbp.iso.pain001.Pain001;
import com.uob.gwb.pbp.po.PwsFileUpload;
import com.uob.gwb.pbp.service.Pain001ProcessService;
import com.uob.gwb.pbp.service.PaymentMappingService;
import com.uob.gwb.pbp.service.PaymentQueryService;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.jetty.util.StringUtil;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("pain001ProcessService")
public class Pain001ProcessServiceImpl extends InboundStepAwareService implements Pain001ProcessService {

    private final PaymentQueryService paymentQueryService;
    private final PaymentMappingService paymentMappingService;

    public SourceProcessStatus processPain001GroupHeader(Pain001 pain001) {
        GroupHeaderDTO groupHeaderDTO = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getGroupHeader();
        String fileRef = groupHeaderDTO.getFilereference();
        if (StringUtil.isEmpty(fileRef)) {
            log.error("source reference is missing");
            return SourceError;
        }
        getResult().setSourceReference(fileRef);
        PwsFileUpload fileUpload = paymentQueryService.getFileUpload(getResult().getSourceReference());
        if (fileUpload == null) {
            log.error("Failed to find file upload with reference: {}", getResult().getSourceReference());
            return SourceError;
        }
        setFileUpload(fileUpload);

        // stop at fileStatus = 02
        DmpFileStatus fileStatus = DmpFileStatus.fromValue(
                pain001.getBusinessDocument().getCustomerCreditTransferInitiation().getGroupHeader().getFilestatus());
        log.info("auth file status: {}", fileStatus);
        getResult().setDmpFileStatus(fileStatus);
        if (DmpFileStatus.REJECTED.equals(fileStatus)) {
            log.info("File rejected by dmp");
            return SourceReject; // stop processing
        }

        // ToDo: validate channel with routeConfig
        // ToDo: validate bankEntity with routeConfig

        // ToDo: sourceFormat from fileUpload or groupHeaderDTO.getFileformat()?

        return SourceOK;
    }

    @Override
    public List<PaymentInformation> processPain001BoMapping(Pain001 pain001) {
        List<PaymentInformation> paymentInfos;
        GroupHeaderDTO groupHeaderDTO = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getGroupHeader();
        try {
            Optional.ofNullable(groupHeaderDTO.getControlSum())
                    .ifPresent((v -> getResult().setPaymentReceivedAmount(Double.parseDouble(v))));
            Optional.ofNullable(groupHeaderDTO.getNumberOfTransactions())
                    .ifPresent(v -> getResult().setTransactionReceivedTotal(Integer.parseInt(v)));
            paymentInfos = pain001.getBusinessDocument()
                    .getCustomerCreditTransferInitiation()
                    .getPaymentInformation()
                    .stream()
                    .map(paymentMappingService::pain001PaymentToBo)
                    .collect(Collectors.toList());
            paymentInfos = paymentMappingService.postMappingPain001ToBo(pain001, paymentInfos);
        } catch (Exception e) {
            log.error("Error on mapping json to bo", e);
            return null; // stop processing
        }
        return paymentInfos;
    }
}
