 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;

import static com.uob.gwb.pbp.flow.SourceProcessStatus.SourceError;
import static com.uob.gwb.pbp.util.Constants.SERVICE_INBOUND;
import static com.uob.gwb.pbp.util.Constants.SYSTEM_DMP;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.gwb.pbp.bo.BankRefMetaData;
import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.FileUploadStatus;
import com.uob.gwb.pbp.bo.validation.RejectOnErrorConfig;
import com.uob.gwb.pbp.config.AppConfig;
import com.uob.gwb.pbp.config.BulkRoutesConfig;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingStatus;
import com.uob.gwb.pbp.flow.PwsSaveRecord;
import com.uob.gwb.pbp.iso.pain001.Pain001;
import com.uob.gwb.pbp.po.PwsFileUpload;
import com.uob.gwb.pbp.po.PwsTransitMessage;
import com.uob.gwb.pbp.service.*;
import com.uob.gwb.pbp.util.Constants;
import com.uob.gwb.pbp.util.PaymentUtils;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@RequiredArgsConstructor
@Slf4j
@Service("pain001InboundService")
public class Pain001InboundServiceImpl extends InboundStepAwareService implements Pain001InboundService {

    private final AppConfig appConfig;
    private final ObjectMapper objectMapper;
    private final PaymentUtils paymentUtils;

    private final Pain001ProcessService pain001ProcessService;
    private final PaymentEnrichmentService paymentEnrichmentService;
    private final PaymentValidationService paymentValidationService;
    private final PaymentDebulkService paymentDebulkService;

    private final PaymentSaveService paymentSaveService;
    private final PaymentUpdateService paymentUpdateService;
    private final PaymentDeleteService paymentDeleteService;

    @Override
    public List<PaymentInformation> processPain001(String json) {
        Pain001 pain001;
        try {
            pain001 = objectMapper.readValue(json, Pain001.class);
        } catch (JsonProcessingException e) {
            log.error("Error on parsing pain001 json", e);
            handleSourceError();
            return null; // stop processing
        }

        pain001ProcessService.beforeStep(getStepExecution());
        // group header
        if (SourceError.equals(pain001ProcessService.processPain001GroupHeader(pain001))) {
            handleSourceError();
            return null; // stop processing
        }
        // convert to BO
        List<PaymentInformation> paymentInfos = pain001ProcessService.processPain001BoMapping(pain001);
        if (CollectionUtils.isEmpty(paymentInfos)) {
            handleSourceError();
            return null; // stop processing
        }
        getResult().setPaymentReceivedTotal(paymentInfos.size());
        getResult().setProcessingStatus(Pain001InboundProcessingStatus.Processing);
        PwsTransitMessage transitMsg = createTransitMessage(getResult().getSourceReference(),
                Pain001InboundProcessingStatus.Processing.name());
        setTransitMessage(transitMsg);

        // reject on error
        prepareRejectOnErrorConfig(pain001);

        // bank ref metadata
        prepareBankRefMetaData();

        return paymentInfos;
    }

    @Override
    public List<PaymentInformation> debulk(List<PaymentInformation> paymentInfos) {
        paymentDebulkService.beforeStep(getStepExecution());
        List<PaymentInformation> debulked = paymentDebulkService.debulk(paymentInfos);
        Pain001InboundProcessingResult result = getResult();
        result.setPaymentDebulkTotal(debulked.size());
        updateProcessing(Pain001InboundProcessingStatus.DebulkPassed);
        return debulked;
    }

    @Override
    public List<PaymentInformation> validate(List<PaymentInformation> paymentInfos) {

        paymentEnrichmentService.beforeStep(getStepExecution());
        paymentValidationService.beforeStep(getStepExecution());

        // entitlement validation
        try {
            paymentInfos = paymentEnrichmentService.enrichPreEntitlementValidation(paymentInfos);
            paymentInfos = paymentValidationService.entitlementValidation(paymentInfos);
            if (Pain001InboundProcessingStatus.RejectOnError.equals(getResult().getProcessingStatus())) {
                handleRejectOnError();
                return null;
            }
            updateProcessing(Pain001InboundProcessingStatus.EntitlementPassed);
        } catch (Exception e) {
            updateProcessingWithException(Pain001InboundProcessingStatus.EnrichmentWithException, e);
        }

        // transaction validation
        try {
            paymentInfos = paymentEnrichmentService.enrichPreTransactionValidation(paymentInfos);
            paymentInfos = paymentValidationService.transactionValidation(paymentInfos);
            if (Pain001InboundProcessingStatus.RejectOnError.equals(getResult().getProcessingStatus())) {
                handleRejectOnError();
                return null;
            }
            updateProcessing(Pain001InboundProcessingStatus.TransactionValidationPassed);
        } catch (Exception e) {
            updateProcessingWithException(Pain001InboundProcessingStatus.TransactionValidationWithException, e);
        }

        // post transaction validation
        try {
            paymentInfos = paymentEnrichmentService.enrichPostTransactionValidation(paymentInfos);
            paymentInfos = paymentValidationService.postTransactionValidation(paymentInfos);
            if (Pain001InboundProcessingStatus.RejectOnError.equals(getResult().getProcessingStatus())) {
                handleRejectOnError();
                return null;
            }
            updateProcessing(Pain001InboundProcessingStatus.PostTransactionValidationPassed);
        } catch (Exception e) {
            updateProcessingWithException(Pain001InboundProcessingStatus.PostTransactionValidationWithException, e);
        }

        // duplicate validation
        paymentInfos = paymentValidationService.duplicationValidation(paymentInfos);
        if (Pain001InboundProcessingStatus.RejectOnError.equals(getResult().getProcessingStatus())) {
            handleRejectOnError();
            return null;
        }

        updateResultAfterValidation(paymentInfos);
        return paymentInfos;
    }

    @Override
    public List<PaymentInformation> enrich(List<PaymentInformation> paymentInfos) {
        paymentEnrichmentService.beforeStep(getStepExecution());
        try {
            paymentInfos = paymentEnrichmentService.enrichPostValidation(paymentInfos);
            updateProcessing(Pain001InboundProcessingStatus.EnrichmentPassed);
        } catch (Exception e) {
            updateProcessingWithException(Pain001InboundProcessingStatus.EnrichmentWithException, e);
        }
        return paymentInfos;
    }

    @Override
    public List<PaymentInformation> save(List<PaymentInformation> paymentInfos) {
        paymentSaveService.beforeStep(getStepExecution());
        paymentDeleteService.beforeStep(getStepExecution());

        boolean noError = true;
        for (PaymentInformation paymentInfo : paymentInfos) {
            if (!paymentInfo.isValid()) {
                try {
                    paymentSaveService.savePaymentInformation(paymentInfo);
                } catch (Exception e) {
                    noError = false;
                    log.error("Failed saving payment", e);
                    Pain001InboundProcessingResult result = getResult();
                    PwsSaveRecord record = paymentUtils.createPwsSaveRecord(
                            paymentInfo.getPwsTransactions().getTransactionId(),
                            paymentInfo.getPwsBulkTransactions().getDmpBatchNumber());
                    paymentUtils.updatePaymentSavedError(result, record);
                    // clean up dirty payment data
                    paymentDeleteService.deletePaymentInformation(paymentInfo);
                }
            } else {
                log.warn("Skipping invalid payment: {}", paymentInfo.getPwsBulkTransactions().getDmpBatchNumber());
            }
        }

        if (noError) {
            updateProcessing(Pain001InboundProcessingStatus.SavePassed);
        } else {
            updateProcessing(Pain001InboundProcessingStatus.SaveWithException);
        }

        return paymentInfos;
    }

    protected void handleSourceError() {
        // ToDo: update exit status?
        getResult().setProcessingStatus(Pain001InboundProcessingStatus.SourceError);
    }

    protected void handleSourceReject() {
        // ToDo: update exit status?
        Pain001InboundProcessingResult result = getResult();
        result.setProcessingStatus(Pain001InboundProcessingStatus.DmpRejected);
        updateFileUploadStatus(FileUploadStatus.UPLOAD_FAILED.name());
        createTransitMessage(result.getSourceReference(), Pain001InboundProcessingStatus.DmpRejected.name());
    }

    protected void handleRejectOnError() {
        // ToDo: update exit status?
        Pain001InboundProcessingResult result = getResult();
        updateFileUploadStatus(FileUploadStatus.UPLOAD_FAILED.name());
        updateTransitMessage(result);
    }

    protected void updateProcessing(Pain001InboundProcessingStatus status) {
        Pain001InboundProcessingResult result = getResult();
        result.setProcessingStatus(status);
        updateTransitMessage(result);
    }

    protected void updateProcessingWithException(Pain001InboundProcessingStatus status, Exception e) {
        log.error("Processing with exception", e);
        Pain001InboundProcessingResult result = getResult();
        result.setProcessingStatus(status);
        updateTransitMessage(result);
    }

    protected PwsFileUpload updateFileUploadStatus(String status) {
        PwsFileUpload fileUpload = getFileUpload();
        fileUpload.setStatus(status);
        paymentUpdateService.updateFileUploadStatus(fileUpload);
        return fileUpload;
    }

    protected PwsTransitMessage createTransitMessage(String fileRef, String status) {
        PwsTransitMessage transitMsg = new PwsTransitMessage();
        transitMsg.setBankReferenceId(fileRef);
        transitMsg.setServiceType(SERVICE_INBOUND);
        transitMsg.setEndSystem(SYSTEM_DMP);
        transitMsg.setMessageRefNo(fileRef);
        transitMsg.setRetryCount(0);
        transitMsg.setProcessingDate(new Date(System.currentTimeMillis()));
        transitMsg.setStatus(status);
        paymentSaveService.createTransitMessage(transitMsg);
        setTransitMessage(transitMsg);
        return transitMsg;
    }

    protected void updateTransitMessage(Pain001InboundProcessingResult result) {
        PwsTransitMessage transitMsg = getTransitMessage();
        transitMsg.setStatus(result.getProcessingStatus().name());
        paymentUpdateService.updateTransitMessageStatus(transitMsg);
    }

    protected RejectOnErrorConfig prepareRejectOnErrorConfig(Pain001 pain001) {
        // ToDo: CU11 gebCompanyId = col25 debtor.name
        String gebCompanyId = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getPaymentInformation()
                .get(0)
                .getDebtor()
                .getName();

        // ToDo: get GEB company id from fileUpload
        // company id: from fileupload -> aes_company_alternative -> geb company id
        String companyId = getFileUpload().getCompanyId();

        // ToDo: REJECT_FILE_ON_ERROR: SELECT REJECT_FILE_ON_ERROR FROM
        // GEB_COMPANY_ATTRIBUTE_MVR WHERE COMPANY_ID = <@p name='companyId'/>

        RejectOnErrorConfig roe = RejectOnErrorConfig.RejectNo;
        setRejectOnError(roe);
        return roe;
    }

    protected BankRefMetaData prepareBankRefMetaData() {
        BulkRoutesConfig.BulkRoute routeConfig = getRouteConfig();
        BankRefMetaData bankRefMetaData = new BankRefMetaData(appConfig.getCountry().name(),
                routeConfig.getChannel().prefix, routeConfig.getRequestType().prefix,
                LocalDateTime.now().format(Constants.BANK_REF_YY_MM));
        setBankRefMetaData(bankRefMetaData);
        return bankRefMetaData;
    }

    protected void updateResultAfterValidation(List<PaymentInformation> paymentInfos) {
        int paymentValidTotal = 0;
        BigDecimal paymentValidAmount = BigDecimal.ZERO;
        int paymentInvalidTotal = 0;
        BigDecimal paymentInvalidAmount = BigDecimal.ZERO;

        for (PaymentInformation paymentInfo : paymentInfos) {
            boolean validPayment = paymentInfo.isValid();
            if (validPayment) {
                paymentValidTotal += 1;
                paymentValidAmount = paymentValidAmount
                        .add(paymentInfo.getPwsTransactions().getTransactionTotalAmount());
                continue;
            }

            // invalid payment
            BigDecimal childTxnInvalidAmount = BigDecimal.ZERO;
            for (CreditTransferTransaction txn : paymentInfo.getCreditTransferTransactionList()) {
                BigDecimal txnAmount = txn.getPwsBulkTransactionInstructions().getTransactionAmount();
                childTxnInvalidAmount = childTxnInvalidAmount.add(txnAmount);
            }

            paymentInvalidTotal += 1;
            paymentInvalidAmount = paymentInvalidAmount.add(childTxnInvalidAmount);
        }

        // update result
        Pain001InboundProcessingResult result = getResult();
        result.setPaymentValidTotal(paymentValidTotal);
        result.setPaymentValidAmount(paymentValidAmount);
        result.setPaymentInvalidTotal(paymentInvalidTotal);
        result.setPaymentInvalidAmount(paymentInvalidAmount);
    }
}
