 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.DmpBulkStatus;
import com.uob.gwb.pbp.data.mapper.Pain001ToBoMapper;
import com.uob.gwb.pbp.flow.BulkProcessingException;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.flow.PwsSaveRecord;
import com.uob.gwb.pbp.iso.pain001.GroupHeaderDTO;
import com.uob.gwb.pbp.iso.pain001.Pain001;
import com.uob.gwb.pbp.service.*;
import com.uob.gwb.pbp.util.PaymentUtils;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service
public class Pain001ServiceImpl extends StepAwareService implements Pain001Service {

    private final ObjectMapper objectMapper;
    private final PaymentUtils paymentUtils;

    private final Pain001ToBoMapper pain001ToBoMapper;
    private final Pain001ToBoService pain001ToBo;
    private final PaymentInformationValidation paymentInfoValidation;
    private final PaymentInformationEnrichment paymentInfoEnrichment;
    private final PaymentDebulkService paymentDebulkService;
    private final PaymentSave paymentSave;

    @Override
    public List<PaymentInformation> validateJson(String json) {
        Pain001 pain001;
        try {
            pain001 = objectMapper.readValue(json, Pain001.class);
        } catch (JsonProcessingException e) {
            throw new BulkProcessingException("Error on parsing pain001 json", e);
        }
        String fileStatus = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getGroupHeader()
                .getFilestatus();
        // ToDo: stop at fileStatus = 02
        List<PaymentInformation> paymentInfos = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getPaymentInformation()
                .stream()
                .map(pain001ToBoMapper::mapToPaymentInformation)
                .collect(Collectors.toList());
        paymentInfos = pain001ToBo.postMappingPain001ToBo(pain001, paymentInfos);
        // ToDo: prepare information for processing
        // 1. pws_resource_configurations ?
        // 2. REJECT_FILE_ON_ERROR: SELECT REJECT_FILE_ON_ERROR FROM
        // GEB_COMPANY_ATTRIBUTE_MVR WHERE COMPANY_ID = <@p name='companyId'/>
        // if payment failed, continue?2. if batch failed, continue?3. if failed, clean
        // data (save)? possible4. if crashed, clean? how?
        // 3. bank ref metadata: channel-code=? transaction-code=?
        // 4. PwsFileUpload: originalfilename -> fileReferenceId
        // 5. process result
        // customerCreditTransferInitiation.groupHeader.numberOfTransactions: no.of
        // payment or total child txn?
        Pain001InboundProcessingResult result = getJobExecutionContext().get("result",
                Pain001InboundProcessingResult.class);
        GroupHeaderDTO groupHeaderDTO = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getGroupHeader();
        result.setPaymentReceivedTotal(
                pain001.getBusinessDocument().getCustomerCreditTransferInitiation().getPaymentInformation().size());
        // ToDo: https://confluencep.sg.uobnet.com/display/GBTCEW/BFU+Mapping+Overview
        // row 8?
        Optional.ofNullable(groupHeaderDTO.getNumberOfTransactions())
                .ifPresent(v -> result.setTransactionReceivedTotal(Integer.valueOf(v)));
        // row 9?
        Optional.ofNullable(groupHeaderDTO.getControlSum())
                .ifPresent((v -> result.setPaymentReceivedAmount(Integer.valueOf(v))));
        // row 10?
        return paymentInfos;
    }

    @Override
    public List<PaymentInformation> debulk(List<PaymentInformation> paymentInfos) {
        paymentDebulkService.beforeStep(getStepExecution());
        List<PaymentInformation> debulked = paymentDebulkService.debulkPaymentInformations(paymentInfos);
        Pain001InboundProcessingResult result = getJobExecutionContext().get("result",
                Pain001InboundProcessingResult.class);
        result.setPaymentDebulkTotal(debulked.size());
        return debulked;
    }

    @Override
    public List<PaymentInformation> validate(List<PaymentInformation> paymentInfos) {
        // ToDo: validate payment
        List<PaymentInformation> enriched = paymentInfoEnrichment.enrichPreValidation(paymentInfos);
        List<PaymentInformation> validated = paymentInfoValidation.validate(enriched);
        return validated;
    }

    @Override
    public List<PaymentInformation> enrich(List<PaymentInformation> paymentInfos) {
        List<PaymentInformation> enriched = paymentInfoEnrichment.enrichPostValidation(paymentInfos);
        ExecutionContext jobContext = getJobExecutionContext();
        Pain001InboundProcessingResult result = jobContext.get("result",
                Pain001InboundProcessingResult.class);
        result.setPaymentDebulkTotal(enriched.size());
        return enriched;
    }

    @Override
    public void save(List<PaymentInformation> paymentInfos) {
        ExecutionContext stepExeContext = getStepExecutionContext();
        ExecutionContext jobContext = getJobExecutionContext();
        for (PaymentInformation paymentInfo : paymentInfos) {
            if (!DmpBulkStatus.REJECTED.equals(paymentInfo.getDmpBulkStatus()) && paymentInfo.isValid()) {
                try {
                    paymentSave.savePaymentInformation(paymentInfo, stepExeContext, jobContext);
                } catch (Exception e) {
                    log.error("Failed saving payment", e);
                    Pain001InboundProcessingResult result = jobContext.get("result",
                            Pain001InboundProcessingResult.class);
                    PwsSaveRecord record = paymentUtils.createPwsSaveRecord(
                            paymentInfo.getPwsTransactions().getTransactionId(),
                            paymentInfo.getPwsBulkTransactions().getDmpBatchNumber());
                    paymentUtils.updatePaymentSavedError(result, record);
                    // ToDo: break or continue
                }
            } else {
                // ToDo: save invalid paymentInfo?
                log.warn("Skipping invalid payment: {}", paymentInfo.getPwsBulkTransactions().getDmpBatchNumber());
            }
        }

        // ToDo: clean up dirty data if partialSuccess not allowed
    }

}
