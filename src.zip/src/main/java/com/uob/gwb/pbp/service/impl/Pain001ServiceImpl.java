 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.gwb.pbp.bo.BankRefMetaData;
import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.DmpBulkStatus;
import com.uob.gwb.pbp.bo.status.DmpFileStatus;
import com.uob.gwb.pbp.config.AppConfig;
import com.uob.gwb.pbp.config.BulkRoutesConfig;
import com.uob.gwb.pbp.flow.BulkProcessingException;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.flow.PwsSaveRecord;
import com.uob.gwb.pbp.iso.pain001.GroupHeaderDTO;
import com.uob.gwb.pbp.iso.pain001.Pain001;
import com.uob.gwb.pbp.po.PwsTransactions;
import com.uob.gwb.pbp.service.*;
import com.uob.gwb.pbp.util.Constants;
import com.uob.gwb.pbp.util.PaymentUtils;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service
public class Pain001ServiceImpl extends StepAwareService implements Pain001Service {

    private final AppConfig appConfig;
    private final ObjectMapper objectMapper;
    private final PaymentUtils paymentUtils;
    private final PaymentMappingService paymentMappingService;
    private final PaymentEnrichmentService paymentEnrichmentService;
    private final PaymentValidationService paymentValidationService;
    private final PaymentDebulkService paymentDebulkService;
    private final PaymentSaveService paymentSaveService;

    @Override
    public List<PaymentInformation> validateJson(String json) {
        Pain001 pain001;
        try {
            pain001 = objectMapper.readValue(json, Pain001.class);
        } catch (JsonProcessingException e) {
            throw new BulkProcessingException("Error on parsing pain001 json", e);
        }
        DmpFileStatus fileStatus = DmpFileStatus.fromValue(
                pain001.getBusinessDocument().getCustomerCreditTransferInitiation().getGroupHeader().getFilestatus());
        log.info("auth file status: {}", fileStatus);
        // ToDo: stop at fileStatus = 02
        Pain001InboundProcessingResult result = getResult();
        GroupHeaderDTO groupHeaderDTO = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getGroupHeader();
        result.setDmpFileStatus(fileStatus);
        result.setSourceReference(groupHeaderDTO.getFilereference());
        Optional.ofNullable(groupHeaderDTO.getControlSum())
                .ifPresent((v -> result.setPaymentReceivedAmount(Double.valueOf(v))));
        Optional.ofNullable(groupHeaderDTO.getNumberOfTransactions())
                .ifPresent(v -> result.setTransactionReceivedTotal(Integer.valueOf(v)));
        List<PaymentInformation> paymentInfos = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getPaymentInformation()
                .stream()
                .map(paymentMappingService::pain001PaymentToBo)
                .collect(Collectors.toList());
        paymentInfos = paymentMappingService.postMappingPain001ToBo(pain001, paymentInfos);
        Optional.ofNullable(paymentInfos).ifPresent(v -> result.setPaymentReceivedTotal(v.size()));

        // ToDo: prepare information for processing
        // 1. pws_resource_configurations ?
        // 2. REJECT_FILE_ON_ERROR: SELECT REJECT_FILE_ON_ERROR FROM
        // GEB_COMPANY_ATTRIBUTE_MVR WHERE COMPANY_ID = <@p name='companyId'/>
        // if payment failed, continue?2. if batch failed, continue?3. if failed, clean
        // data (save)? possible4. if crashed, clean? how?
        // ToDo: https://confluencep.sg.uobnet.com/display/GBTCEW/BFU+Mapping+Overview
        // row 8?
        // row 9?
        // row 10?
        // ToDo: pws_file_uplaods originalfilename -> fileReferenceId
        // ToDo: pws_transit_messages

        BulkRoutesConfig.BulkRoute routeConfig = getRouteConfig();
        BankRefMetaData bankRefMetaData = new BankRefMetaData(appConfig.getCountry().name(),
                routeConfig.getChannel().prefix, routeConfig.getRequestType().prefix,
                LocalDateTime.now().format(Constants.BANK_REF_YY_MM));
        setBankRefMetaData(bankRefMetaData);

        return paymentInfos;
    }

    @Override
    public List<PaymentInformation> debulk(List<PaymentInformation> paymentInfos) {
        paymentDebulkService.beforeStep(getStepExecution());
        List<PaymentInformation> debulked = paymentDebulkService.debulk(paymentInfos);
        Pain001InboundProcessingResult result = getResult();
        result.setPaymentDebulkTotal(debulked.size());
        return debulked;
    }

    @Override
    public List<PaymentInformation> validate(List<PaymentInformation> paymentInfos) {
        paymentEnrichmentService.beforeStep(getStepExecution());
        List<PaymentInformation> enriched = paymentEnrichmentService.enrichPreValidation(paymentInfos);
        paymentValidationService.beforeStep(getStepExecution());
        List<PaymentInformation> validated = paymentValidationService.validate(enriched);
        updateAfterValidation(validated);
        return validated;
    }

    @Override
    public List<PaymentInformation> enrich(List<PaymentInformation> paymentInfos) {
        // ToDo: PWS_TAX_INSTRUCTIONS.TAX_AMOUNT (SUM of all tax records for the txn)
        paymentEnrichmentService.beforeStep(getStepExecution());
        List<PaymentInformation> enriched = paymentEnrichmentService.enrichPostValidation(paymentInfos);
        return enriched;
    }

    @Override
    public void save(List<PaymentInformation> paymentInfos) {
        paymentSaveService.beforeStep(getStepExecution());
        for (PaymentInformation paymentInfo : paymentInfos) {
            if (!paymentInfo.isValid()) {
                try {
                    paymentSaveService.savePaymentInformation(paymentInfo);
                } catch (Exception e) {
                    log.error("Failed saving payment", e);
                    Pain001InboundProcessingResult result = getResult();
                    PwsSaveRecord record = paymentUtils.createPwsSaveRecord(
                            paymentInfo.getPwsTransactions().getTransactionId(),
                            paymentInfo.getPwsBulkTransactions().getDmpBatchNumber());
                    paymentUtils.updatePaymentSavedError(result, record);
                    // ToDo: clean up dirty payment data
                    // ToDo: break or continue
                }
            } else {
                log.warn("Skipping invalid payment: {}", paymentInfo.getPwsBulkTransactions().getDmpBatchNumber());
            }
        }


    }

    private void handleProcessingStatus(RouteConfig Pain001InboundProcessingResult result) {
        // ToDo: update file
    }
    private void updateAfterValidation(List<PaymentInformation> paymentInfos) {
        int paymentValidTotal = 0;
        BigDecimal paymentValidAmount = BigDecimal.ZERO;
        int paymentInvalidTotal = 0;
        BigDecimal paymentInvalidAmount = BigDecimal.ZERO;

        for (int i = 0; i < paymentInfos.size(); i++) {
            PaymentInformation paymentInfo = paymentInfos.get(i);
            boolean validPayment = paymentInfo.isValid();

            int childTxnValidTotal = 0;
            BigDecimal childTxnValidAmount = BigDecimal.ZERO;
            BigDecimal childTxnMaxAmount = BigDecimal.ZERO;
            BigDecimal childTxnInvalidAmount = BigDecimal.ZERO;

            for (int j = 0; j < paymentInfo.getCreditTransferTransactionList().size(); j++) {
                CreditTransferTransaction txn = paymentInfo.getCreditTransferTransactionList().get(j);
                BigDecimal txnAmount = txn.getPwsBulkTransactionInstructions().getTransactionAmount();
                if (validPayment && txn.isValid()) {
                    // for valid payment & valid txn
                    childTxnValidTotal += 1;
                    childTxnValidAmount.add(txnAmount);
                    childTxnMaxAmount = (childTxnMaxAmount.compareTo(txnAmount) < 0) ? txnAmount : childTxnMaxAmount;
                }

                // for valid payment & invalid txn
                // for invalid payment
                childTxnInvalidAmount.add(txnAmount);
            }

            if (validPayment && childTxnValidTotal > 0) {
                PwsTransactions pwsTransactions = paymentInfo.getPwsTransactions();
                pwsTransactions.setTotalChild(childTxnValidTotal);
                pwsTransactions.setTotalAmount(childTxnValidAmount);
                pwsTransactions.setMaximumAmount(childTxnMaxAmount);
                paymentValidTotal += 1;
                paymentValidAmount.add(childTxnValidAmount);
                continue;
            }

            paymentInvalidTotal += 1;
            paymentInvalidAmount.add(childTxnInvalidAmount);
        }

        // update result
        Pain001InboundProcessingResult result = getResult();
        result.setPaymentValidTotal(paymentValidTotal);
        result.setPaymentValidAmount(paymentValidAmount);
        result.setPaymentInvalidTotal(paymentInvalidTotal);
        result.setPaymentInvalidAmount(paymentInvalidAmount);
    }

}
