 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.config;


import com.zaxxer.hikari.HikariDataSource;
import java.util.Properties;
import javax.sql.DataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;

@Configuration
public class DataSourceConfig {

    private final Environment env;

    public DataSourceConfig(Environment env) {
        this.env = env;
    }

    @Bean
    @Primary
    @ConfigurationProperties("spring.datasource.default")
    public DataSource defaultDataSource() {
        return createDataSource("spring.datasource.primary");
    }

    @Bean
    @ConfigurationProperties("spring.datasource.payment-save")
    public DataSource paymentSaveDataSource() {
        return createDataSource("spring.datasource.payment-insertion");
    }

    @Bean
    @ConfigurationProperties("spring.datasource.payment-loading")
    public DataSource paymentLoadingDataSource() {
        return createDataSource("spring.datasource.payment-loading");
    }

    private DataSource createDataSource(String prefix) {
        HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();

        // Set common properties
        dataSource.setDriverClassName(env.getProperty("spring.datasource.common.driver-class-name"));
        dataSource.setJdbcUrl(env.getProperty(prefix + ".jdbc-url"));
        dataSource.setUsername(env.getProperty(prefix + ".username"));
        dataSource.setPassword(env.getProperty(prefix + ".password"));

        // Set Hikari-specific properties
        dataSource.setMaximumPoolSize(
                env.getProperty("spring.datasource.common.hikari.maximum-pool-size", Integer.class));
        dataSource.setMinimumIdle(env.getProperty("spring.datasource.common.hikari.minimum-idle", Integer.class));
        dataSource.setIdleTimeout(env.getProperty("spring.datasource.common.hikari.idle-timeout", Long.class));
        dataSource.setConnectionTimeout(
                env.getProperty("spring.datasource.common.hikari.connection-timeout", Long.class));
        dataSource.setMaxLifetime(env.getProperty("spring.datasource.common.hikari.max-lifetime", Long.class));

        // Configure Oracle Vault if enabled
        if (Boolean.parseBoolean(env.getProperty("spring.datasource.common.vault.enabled"))) {
            Properties props = new Properties();
            props.setProperty("oracle.net.wallet_location",
                    env.getProperty("spring.datasource.common.vault.wallet-location"));
            props.setProperty("javax.net.ssl.keyStore", env.getProperty("spring.datasource.common.vault.key-store"));
            props.setProperty("javax.net.ssl.keyStorePassword",
                    env.getProperty("spring.datasource.common.vault.key-store-password"));
            props.setProperty("javax.net.ssl.keyStoreType",
                    env.getProperty("spring.datasource.common.vault.key-store-type"));
            props.setProperty("javax.net.ssl.trustStore",
                    env.getProperty("spring.datasource.common.vault.trust-store"));
            props.setProperty("javax.net.ssl.trustStorePassword",
                    env.getProperty("spring.datasource.common.vault.trust-store-password"));

            dataSource.setDataSourceProperties(props);
        }

        return dataSource;
    }
}
