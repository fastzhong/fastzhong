 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.service.CreditTransferTransactionEnrichment;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Slf4j
@Component
public class CreditTransferTransactionEnrichmentImpl extends StepAwareService
        implements
            CreditTransferTransactionEnrichment {

    @Override
    public List<CreditTransferTransaction> enrichPreValidation(List<CreditTransferTransaction> creditTransferTxns) {
        // ToDo:
        return null;
    }

    @Override
    public List<CreditTransferTransaction> enrichPostValidation(List<CreditTransferTransaction> creditTransferTxns) {
        // ToDo:
        return null;
    }
}
