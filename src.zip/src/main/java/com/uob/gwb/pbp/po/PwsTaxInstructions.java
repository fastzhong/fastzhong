 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import java.math.BigDecimal;
import lombok.Data;

@Data
public class PwsTaxInstructions {
    private String bankReferenceId;
    private String childBankReferenceId;
    private Long transactionId;
    private String taxType;
    private String taxReturnType;
    private String paymentCondition;
    private String documentNumber;
    private String taxSequenceNumber;
    private BigDecimal taxableAmount;
    private String typeOfIncome;
    private BigDecimal taxRate;
    private String taxDescription;
    private BigDecimal taxAmount;
    private BigDecimal vatAmount;
    private String vatBranchCode;
    private String taxPayerName;
    private String taxPayerId;
    private String taxPayeeName;
    private String taxPayeeId;
    private String taxSubscription;
    private String payerVatBranchCode;
    private String payeeVatBranchCode;
}
