 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

public abstract class StepAwareService {

    protected StepExecution stepExecution;

    public void beforeStep(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    public void afterStep(StepExecution stepExecution) {
        // Subclasses can optionally override this method
    }

    protected JobExecution getJobExecution() {
        return stepExecution.getJobExecution();
    }

    protected ExecutionContext getJobExecutionContext() {
        return stepExecution.getJobExecution().getExecutionContext();
    }

    protected StepExecution getStepExecution() {
        return this.stepExecution;
    }

    protected ExecutionContext getStepExecutionContext() {
        return stepExecution.getExecutionContext();
    }

}
