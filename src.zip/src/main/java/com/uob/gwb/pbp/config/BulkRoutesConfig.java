 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.config;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "bulk-routes")
@Data
public class BulkRoutesConfig {
    private List<RouteConfig> routes;

    @Getter
    public enum ProcessingType
    {
        INBOUND, OUTBOUND
    }

    @Getter
    public enum SourceDestinationType
    {
        FILE, JDBC, MESSAGE, API
    }

    @Data
    public static class RouteConfig {
        @NotBlank
        private String routeName;

        @NotBlank
        private ProcessingType processingType;

        private SourceDestinationType sourceType;
        private SourceDestinationType destinationType;

        private boolean enabled = false;

        @NotEmpty
        private List<String> steps;

        private FileSource fileSource;
        // ToDo: JdbcResource, JmsResource, ApiResource
        private PaymentSave paymentSave;
        private PaymentLoading paymentLoading;
        private Pain001Transformation pain001Transformation;
        private FileDestination fileDestination;
        // ToDo: JdbcDestination, JmsDestination, ApiDestination
    }

    @Data
    public static class FileSource {
        private String directoryName;
        private String antInclude;
        private String antExclude;
        private String charset;
        private String doneFileName;
        private int delay;
        private String sortBy;
        private int maxMessagesPerPoll;
        private boolean noop;
        private boolean recursive;
        private String move;
        private String moveFailed;
        private String readLock;
        private int readLockTimeout;
        private int readLockInterval;
        private String readLockLoggingLevel;
    }

    @Data
    public static class PaymentSave {
        private String datasource;
    }

    @Data
    public static class PaymentLoading {
        private String datasource;
        private String cron;
    }

    @Data
    public static class Pain001Transformation {
        private String templatePath;
    }

    @Data
    public static class FileDestination {
        private String directoryName;
        private String fileName;
        private String tempFileName;
        private String doneFileName;
        private boolean autoCreate;
        private String fileExist;
        private String moveExisting;
        private boolean eagerDeleteTargetFile;
        private boolean delete;
        private String chmod;
    }

}
