 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import java.math.BigDecimal;
import java.sql.Timestamp;
import lombok.Data;
import org.apache.commons.lang3.ObjectUtils;

@Data
public class PwsTransactions {

    private long transactionId;
    private String accountCurrency;
    private String accountNumber;
    private String authorizationStatus;
    private String captureStatus;
    private Long companyGroupId;
    private Long companyId;
    private String companyName;
    private String wizard;
    private Timestamp initiationTime;
    private Timestamp releaseDate;
    private String processingStatus;
    private String bankEntityId;
    private String bankReferenceId;
    private String resourceId;
    private long changeToken;
    private long initiatedBy;
    private long releasedBy;
    private BigDecimal maximumAmount;
    private String featureId;
    private String applicationType;
    private String correlationId;
    private String customerTransactionStatus;
    private String rejectReason;
    private String transactionCurrency;
    private BigDecimal transactionTotalAmount;
    private boolean terminatedByDebtorFlag;
    private BigDecimal highestAmount;
    private String accountPAB;
    private int totalChild;
    private BigDecimal totalAmount;
    private Long originalTransactionId;
    private String transactionCategory;

    public String mapKeyAttributes() {
        String source = this.companyId + "_" + this.companyGroupId + "_" + this.accountNumber + "_"
                + (ObjectUtils.isNotEmpty(this.transactionCategory) ? this.transactionCategory : this.resourceId) + "_"
                + this.featureId + "_" + this.transactionCurrency + "_" + this.accountCurrency + "_"
                + this.customerTransactionStatus;
        return source;
    }
}
