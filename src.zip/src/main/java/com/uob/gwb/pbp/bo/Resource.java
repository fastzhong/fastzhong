 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.bo;

public enum Resource
{
    IAFT("iaft"), SMART("smart"), SMART_SAME_DAY("smart-same-day"), BAHTNET("bahtnet");
    public final String id;
    private Resource(String id) {
        this.id = id;
    }
    public static Resource fromValue(String id) {
        for (Resource resource : Resource.values()) {
            if (resource.id.equals(id)) {
                return resource;
            }
        }
        throw new IllegalArgumentException("invalid id for Resource");
    }
}
