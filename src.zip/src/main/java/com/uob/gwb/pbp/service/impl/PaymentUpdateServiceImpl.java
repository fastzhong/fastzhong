 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.dao.PwsUpdateDao;
import com.uob.gwb.pbp.po.PwsFileUpload;
import com.uob.gwb.pbp.po.PwsTransitMessage;
import com.uob.gwb.pbp.service.PaymentUpdateService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("paymentUpdateService")
public class PaymentUpdateServiceImpl implements PaymentUpdateService {

    private final PwsUpdateDao pwsUpdateDao;

    @Override
    public void updateFileUploadStatus(PwsFileUpload fileUpload) {
        pwsUpdateDao.updateFileUploadStatus(fileUpload);

    }

    @Override
    public void updateTransitMessageStatus(PwsTransitMessage transitMsg) {
        pwsUpdateDao.updateTransitMessageStatus(transitMsg);

    }

}
