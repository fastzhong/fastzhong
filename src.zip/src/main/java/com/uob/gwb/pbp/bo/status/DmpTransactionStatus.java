 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.bo.status;

public enum DmpTransactionStatus
{

    APPROVED("01"), REJECTED("02");

    public final String value;

    private DmpTransactionStatus(String value) {
        this.value = value;
    }

    public static DmpTransactionStatus fromValue(String value) {
        for (DmpTransactionStatus status : DmpTransactionStatus.values()) {
            if (status.value.equalsIgnoreCase(value)) {
                return status;
            }
        }
        throw new IllegalArgumentException("invalid value for DmpTransactionStatus");
    }
}
