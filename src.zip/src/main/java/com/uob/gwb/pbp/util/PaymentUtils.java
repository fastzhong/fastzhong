 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.util;


import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.flow.PwsSaveRecord;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
public class PaymentUtils {

    public PwsSaveRecord createPwsSaveRecord(long id, String dmpTxnRef) {
        dmpTxnRef = Optional.ofNullable(dmpTxnRef).orElse("");
        return new PwsSaveRecord(id, dmpTxnRef);
    }

    public void updatePaymentSaved(Pain001InboundProcessingResult result, PwsSaveRecord record) {
        result.getPaymentSaved().add(record);
    }

    public void updatePaymentSavedError(Pain001InboundProcessingResult result, PwsSaveRecord record) {
        // for error, record only once
        if (!result.getPaymentSavedError().contains(record))
            result.getPaymentSavedError().add(record);
    }
}
