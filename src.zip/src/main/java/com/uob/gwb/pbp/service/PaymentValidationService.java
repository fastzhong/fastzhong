 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service;


import com.uob.gwb.pbp.bo.PaymentInformation;
import java.util.List;
import org.springframework.batch.core.StepExecution;

public interface PaymentValidationService {

    void beforeStep(StepExecution stepExecution);

    void afterStep(StepExecution stepExecution);

    List<PaymentInformation> entitlementValidation(List<PaymentInformation> paymentInfos);

    List<PaymentInformation> transactionValidation(List<PaymentInformation> paymentInfos);

    List<PaymentInformation> postTransactionValidation(List<PaymentInformation> paymentInfos);

    List<PaymentInformation> duplicationValidation(List<PaymentInformation> paymentInfos);

}
