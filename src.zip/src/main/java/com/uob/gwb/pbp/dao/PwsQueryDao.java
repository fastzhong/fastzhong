package com.uob.gwb.pbp.dao;

import org.springframework.stereotype.Repository;

@Repository("pwsQueryDao")
public interface PwsQueryDao {
}
