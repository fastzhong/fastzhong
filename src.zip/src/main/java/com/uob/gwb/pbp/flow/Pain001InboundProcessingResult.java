 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.flow;


import com.uob.gwb.pbp.bo.status.BulkProcessingStatus;
import com.uob.gwb.pbp.bo.status.DmpFileStatus;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class Pain001InboundProcessingResult {

    String sourceReference;
    DmpFileStatus dmpFileStatus;
    BulkProcessingStatus bulkProcessingStatus;


    // 1. received from dmp
    int paymentReceivedTotal = 0;
    int transactionReceivedTotal = 0;
    double paymentReceivedAmount = 0;

    // 2. debulk
    int paymentDebulkTotal = 0;

    // 3. validation
    int paymentValidTotal = 0;
    BigDecimal paymentValidAmount;
    int paymentInvalidTotal = 0;
    BigDecimal paymentInvalidAmount;
    // ToDo:
    // List<String> paymentValid = new ArrayList<>();
    // List<String> paymentInvalid = new ArrayList<>();
    // List<String> paymentValidationError = new ArrayList<>();

    // 4. enrichment
    List<String> paymentEnrichmentError = new ArrayList<>();

    // 5. save
    int paymentCreatedTotal = 0;
    int paymentTxnCreatedTotal = 0;
    List<PwsSaveRecord> paymentSaved = new ArrayList<>();
    List<PwsSaveRecord> paymentSavedError = new ArrayList<>();

}
