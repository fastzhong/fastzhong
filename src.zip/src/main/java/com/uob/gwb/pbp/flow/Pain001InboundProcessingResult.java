 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.flow;


import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class Pain001InboundProcessingResult {

    // 1. received from dmp (dmp successful? successful+rejected?)
    int paymentReceivedTotal = 0;
    int transactionReceivedTotal = 0;
    int paymentReceivedAmount = 0;

    // 2. debulk
    int paymentDebulkTotal = 0;

    // 3. validation
    int paymentValidTotal = 0;
    double paymentValidAmount = 0;
    int paymentInvalidTotal = 0;
    double paymentInvalidAmount = 0;
    List<String> paymentValid = new ArrayList<>();
    List<String> paymentInvalid = new ArrayList<>();
    List<String> paymentValidationError = new ArrayList<>();

    // 4. enrichment
    List<String> paymentEnrichmentError = new ArrayList<>();

    // 5. save
    int paymentCreatedTotal = 0;
    int paymentTxnCreatedTotal = 0;
    List<PwsSaveRecord> paymentSaved;
    List<PwsSaveRecord> paymentSavedError;

    public void increasePaymentCreatedTotal() {
        this.paymentCreatedTotal += 1;
    }

    public void increasePaymentTxnCreatedTotal(int numOfChildTxn) {
        this.paymentTxnCreatedTotal += numOfChildTxn;
    }

}
