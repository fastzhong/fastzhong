 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import java.time.LocalDateTime;
import lombok.*;

@Data
public class PwsFileUpload {
    private String fileUploadId;
    private String fileReferenceId;
    private String transactionId;
    private String fileType;
    private String uploadFileName;
    private String companyId;
    private String status;
    private String createdBy;
    private String createdDate;
    private String featureId;
    private String resourceId;
    private String fileSize;
    private LocalDateTime currentDate;
    private String uploadFilePath;
    private String fileUploadStatus;
    private String fileStagingId;
    private String userId;
}
