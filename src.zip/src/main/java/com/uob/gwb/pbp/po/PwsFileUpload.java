 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import java.sql.Date;
import lombok.*;

@Data
public class PwsFileUpload {
    private String fileUploadId;
    private String resourceId;
    private String featureId;
    private String resourceCategory;
    private String fileReferenceId;
    private String fileType;
    private String fileTypeEnum;
    private String fileSubTypeEnum;
    private String uploadFilePath;
    private String uploadFileName;
    private String fileSize;
    private String chargeOption;
    private String payrollOption;
    private String status;
    private String transactionId;
    private String companyId;
    private String accountId;
    private long changeToken;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;

}
