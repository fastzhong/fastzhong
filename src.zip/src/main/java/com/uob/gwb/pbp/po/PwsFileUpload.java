 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import lombok.Data;

@Data
public class PwsFileUpload {
    private String fileUploadId;
    private String fileReferenceId;
    private String fileStagingId;
    private String transactionId;

    private String featureId;
    private String resourceId;
    private String fileTypeEnum;
    private String fileSubTypeEnum;

    private String uploadFileName;
    private String uploadFilePath;
    private long fileSize;

    private String userId;
    private String companyId;
    private String accountId;
    private String resourceCategory;
    private String chargeOption;
    private String payrollOption;

    private String fileUploadStatus;
    private String status;
    private String createdBy;
    private String createdDate;
    private String changeToken;
}
