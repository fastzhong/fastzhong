 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import java.time.OffsetDateTime;
import lombok.Data;

@Data
public class PwsParties {
    private Long partyId;
    private String bankEntityId;
    private Long transactionId;
    private String bankReferenceId;
    private String childBankReferenceId;
    private String bankCode;
    private String partyAccountType;
    private String partyAccountNumber;
    private String partyAccountName;
    private String partyAccountCurrency;
    private String partyAgentBIC;
    private String partyName;
    private String partyRole;
    private String residentialStatus;
    private String proxyId;
    private String proxyIdType;
    private String idIssuingCountry;
    private String productType;
    private String primaryIdentificationType;
    private String primaryIdentificationValue;
    private String secondaryIdentificationType;
    private String secondaryIdentificationValue;
    private String registrationId;
    private Long beneficiaryReferenceId;
    private String swiftCode;
    private String partyType;
    private String residencyStatus;
    private String accountOwnership;
    private String relationshipType;
    private String ultimatePayeeCountryCode;
    private String ultimatePayeeName;
    private OffsetDateTime partyModifiedDate;
    private long beneficiaryChangeToken;
    private Boolean isNew;
    private String isPreapproved;
    private Long bankId;
}
