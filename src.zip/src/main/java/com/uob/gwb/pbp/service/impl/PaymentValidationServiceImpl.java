 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.validation.RejectOnErrorConfig;
import com.uob.gwb.pbp.bo.validation.TransactionValidationRecord;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingStatus;
import com.uob.gwb.pbp.po.PwsTransactions;
import com.uob.gwb.pbp.service.DecisionMatrixService;
import com.uob.gwb.pbp.service.PaymentValidationService;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("paymentValidationService")
public class PaymentValidationServiceImpl extends InboundStepAwareService implements PaymentValidationService {

    // ToDo: qulified if multiple decision matrix
    private final DecisionMatrixService txnValidationService;

    // entitlement check
    @Override
    public List<PaymentInformation> entitlementValidation(List<PaymentInformation> paymentInfos) {
        // ToDo:
        // 1. user resource feature entitlement
        // - Checks resource (e.g., CROSS_BORDER_UOBSEND) access
        // - Validates feature permissions
        // - Verifies CREATE action permission
        // 2. company & account entitlement
        // - Validates company exists and is authorized
        // - Checks account belongs to company
        // - Verifies account permissions
        // - Validates account-resource-feature combination
        return paymentInfos;
    }

    // txn level validation
    @Override
    public List<PaymentInformation> transactionValidation(List<PaymentInformation> paymentInfos) {
        // ToDo:
        /*
         * a) IBAN and Batch Booking: - IBAN validation for account - Batch booking
         * settings validation - Payment code validation for specific currencies -
         * Transaction amount validation
         *
         * b) Bank and Contact Details: - Bank code validation - SWIFT code validation -
         * Phone number validation for specific currencies - Creditor name validation -
         * Address line validation
         *
         * c) Currency and Country: - Currency code validation - Country code validation
         * - Purpose code validation for specific currencies - Transaction currency
         * validation - Contract ID validation for FX transactions
         */

        List<TransactionValidationRecord> records = new ArrayList<>();

        for (PaymentInformation paymentInfo : paymentInfos) {
            TransactionValidationRecord txnValidationRecord = createTransactionValidationRecord(paymentInfo);
            records.add(txnValidationRecord);
        }

        ExecutionContext validationContext = createTransactionValidationContext(paymentInfos);

        if (RejectOnErrorConfig.RejectYes.equals(getRejectOnError())) {
            boolean stop = txnValidationService.applyRulesShouldStop(records, validationContext, true);
            if (stop) {
                getResult().setProcessingStatus(Pain001InboundProcessingStatus.RejectOnError);
            }
        } else {
            txnValidationService.applyRules(records, validationContext);
        }
        return paymentInfos;

    }

    @Override
    public List<PaymentInformation> postTransactionValidation(List<PaymentInformation> paymentInfos) {
        // ToDo: bulk booking validation
        return paymentInfos;
    }

    @Override
    public List<PaymentInformation> duplicationValidation(List<PaymentInformation> paymentInfos) {
        // ToDo:
        // 2 levels: file or txn
        // 4 scenarios
        // basePath: http://lxcewtsgv093:8087/paymentcbpworkflowservice
        // duplicateCheckUri: /api/cbp/v1/duplicateCheck
        return paymentInfos;
    }

    @NotNull
    protected TransactionValidationRecord createTransactionValidationRecord(PaymentInformation paymentInfo) {
        TransactionValidationRecord txnValidationRecord = new TransactionValidationRecord();
        txnValidationRecord.getCountryCode();
        txnValidationRecord.setChannel(getChannel());
        txnValidationRecord.getBankEntityId();
        txnValidationRecord.setSourceFormat(getSourceFormat().name());
        PwsTransactions pwsTransactions = paymentInfo.getPwsTransactions();
        txnValidationRecord.setResourceId(pwsTransactions.getResourceId());
        txnValidationRecord.setFeatureId(pwsTransactions.getFeatureId());
        for (CreditTransferTransaction txn : paymentInfo.getCreditTransferTransactionList()) {
            txnValidationRecord.setTransaction(txn);
        }
        return txnValidationRecord;
    }

    protected ExecutionContext createTransactionValidationContext(List<PaymentInformation> paymentInfos) {
        // ToDo: prepare validation context
        return getStepContext();
    }

}
