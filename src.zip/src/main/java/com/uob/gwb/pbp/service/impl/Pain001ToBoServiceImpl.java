 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.iso.pain001.GroupHeaderDTO;
import com.uob.gwb.pbp.iso.pain001.Pain001;
import com.uob.gwb.pbp.service.Pain001ToBoService;
import com.uob.gwb.pbp.util.GeneralUtils;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Slf4j
@Component
public class Pain001ToBoServiceImpl extends StepAwareService implements Pain001ToBoService {

    @Override
    public List<PaymentInformation> postMappingPain001ToBo(Pain001 pain001, List<PaymentInformation> paymentInfos) {

        // ToDo:
        // 8. message Identification
        // Cew Bank Reference Number, File ID, example: SG_PA1130208001.xml
        // customerCreditTransferInitiation.groupHeader.messageIdentification
        // PWS_TRANSACTIONS.BANK_REFERENCE_ID ?
        // 24. date Customer Input Data
        // Value Date Customer provided value date
        // customerCreditTransferInitiation.paymentInformation.requestedExecutionDate.date
        // PWS_TRANSACTION_INSTRUCTIONS.ORIGINAL_VALUE_DATE ?

        GroupHeaderDTO groupHeaderDTO = pain001.getBusinessDocument()
                .getCustomerCreditTransferInitiation()
                .getGroupHeader();
        for (PaymentInformation paymentInfo : paymentInfos) {
            paymentInfo.getPwsBulkTransactions()
                    .setTransferDate(GeneralUtils.stringToDate(groupHeaderDTO.getCreationDateTime()));

        }

        return paymentInfos;
    }
}
