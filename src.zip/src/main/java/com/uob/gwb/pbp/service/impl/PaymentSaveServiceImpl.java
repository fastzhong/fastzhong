 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.BankRefMetaData;
import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.Party;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.config.AppConfig;
import com.uob.gwb.pbp.dao.PwsSaveDao;
import com.uob.gwb.pbp.flow.BulkProcessingException;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.flow.PwsSaveRecord;
import com.uob.gwb.pbp.po.*;
import com.uob.gwb.pbp.service.PaymentSaveService;
import com.uob.gwb.pbp.util.PaymentUtils;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@RequiredArgsConstructor
@Slf4j
@Component
public class PaymentSaveServiceImpl extends StepAwareService implements PaymentSaveService {

    private final AppConfig appConfig;
    private final RetryTemplate retryTemplate;
    private final SqlSessionTemplate paymentSaveSqlSessionTemplate;
    private final PaymentUtils paymentUtils;
    private final PwsSaveDao pwsSaveDao;

    public void savePaymentInformation(PaymentInformation paymentInfo) {

        int batchInsertSize = appConfig.getBatchInsertSize();

        Pain001InboundProcessingResult result = getResult();
        PwsSaveRecord record = paymentUtils.createPwsSaveRecord(paymentInfo.getPwsTransactions().getTransactionId(),
                paymentInfo.getPwsBulkTransactions().getDmpBatchNumber());

        // save bulk payment
        long txnId = saveBulkPayment(paymentInfo);

        // ToDo: save invalid txns?
        List<CreditTransferTransaction> validTxns = paymentInfo.getCreditTransferTransactionList()
                .stream()
                .filter(CreditTransferTransaction::isValid)
                .toList();
        int totalTxns = validTxns.size();
        int totalBatches = (totalTxns + batchInsertSize - 1) / batchInsertSize;
        log.info("Save {} child transactions in {} batches", totalTxns, totalBatches);

        // save child txns in batch
        boolean noError = true;
        for (int i = 0; i < totalBatches; i++) {
            int from = i * batchInsertSize;
            int to = Math.min(from + batchInsertSize, totalTxns);
            List<CreditTransferTransaction> batch = validTxns.subList(from, to);
            int batchNum = i + 1;

            try {
                retryTemplate.execute(context -> {
                    if (ObjectUtils.isNotEmpty(context)) {
                        log.info("Attempting to save child transactions, try: {}", context.getRetryCount() + 1);
                    }
                    saveCreditTransferBatch(batch, txnId, paymentInfo.getPwsTransactions().getBankReferenceId(),
                            batchNum);
                    return null;
                }, context -> {
                    log.error("Failed to save child transactions after all retries", context.getLastThrowable());
                    throw new BulkProcessingException("Failed to insert bulk transaction instructions after retries",
                            context.getLastThrowable());
                });
            } catch (Exception e) {
                noError = false;
                log.error("Failed saving batch {}: ", i + 1, e);
                // ToDo: break or continue?
            }
        }

        if (noError) {
            log.info("Successful saving payment & its child txns: {}", record);
            result.setPaymentCreatedTotal(result.getPaymentCreatedTotal() + 1);
            result.setPaymentTxnCreatedTotal(result.getPaymentTxnCreatedTotal() + totalTxns);
            paymentUtils.updatePaymentSaved(result, record);
        } else {
            paymentUtils.updatePaymentSavedError(result, record);
        }

    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    long saveBulkPayment(PaymentInformation paymentInfo) {
        int seqNo = pwsSaveDao.getBankRefSequenceNum();
        BankRefMetaData bankRefMetaData = getBankRefMetadata();
        String bankRefId = bankRefMetaData.generateBankRefId(seqNo);
        PwsTransactions pwsTransactions = paymentInfo.getPwsTransactions();
        pwsTransactions.setBankReferenceId(bankRefId);
        long changeToken = LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        pwsTransactions.setChangeToken(changeToken);
        long txnId = pwsSaveDao.insertPwsTransactions(pwsTransactions);
        pwsTransactions.setTransactionId(txnId);
        log.debug("Successful saving pwsTransactions: {}", pwsTransactions);

        long bulkChangeToken = LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();;
        PwsBulkTransactions pwsBulkTransactions = paymentInfo.getPwsBulkTransactions();
        pwsBulkTransactions.setTransactionId(txnId);
        pwsBulkTransactions.setChangeToken(bulkChangeToken);
        long bulkTxnId = pwsSaveDao.insertPwsBulkTransactions(pwsBulkTransactions);
        pwsBulkTransactions.setBkTransactionId(bulkTxnId);
        log.debug("Successful saving pwsBulkTransactions: {}", pwsBulkTransactions);

        return txnId;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    private void saveCreditTransferBatch(List<CreditTransferTransaction> batch, long txnId, String parentBankRefId,
            int batchNum) {

        int batchInsertSize = batch.size();

        // ToDo: generate child bank reference IDs for the batch
        List<Integer> bankRefSeqNums = pwsSaveDao.getBatchBankRefSequenceNum(batchInsertSize);
        BankRefMetaData bankRefMetaData = getBankRefMetadata();
        List<String> childBankRefIds = bankRefSeqNums.stream().map(bankRefMetaData::generateBankRefId).toList();
        long beneChangeToken = LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();

        TransactionBatchCollections collections = new TransactionBatchCollections();
        for (int i = 0; i < batchInsertSize; i++) {
            CreditTransferTransaction creditTransfer = batch.get(i);
            String childBankRefId = childBankRefIds.get(i);
            collectTransactionBatchRecords(creditTransfer, txnId, parentBankRefId, childBankRefId, beneChangeToken,
                    collections);
        }

        executeBatchInsertsInOrder(collections, batchNum);

    }

    private void collectTransactionBatchRecords(CreditTransferTransaction creditTransfer, long txnId,
            String parentBankRefId, String childBankRefId, long beneChangeToken,
            TransactionBatchCollections collections) {

        // Collect transaction instructions
        PwsBulkTransactionInstructions txnInstruction = creditTransfer.getPwsBulkTransactionInstructions();
        txnInstruction.setBankReferenceId(parentBankRefId);
        txnInstruction.setChildBankReferenceId(childBankRefId);
        collections.getTxnInstructions().add(txnInstruction);

        // Party
        Party party = creditTransfer.getParty();
        PwsParties pwsParties = party.getPwsParties();
        pwsParties.setTransactionId(txnId);
        pwsParties.setBankReferenceId(parentBankRefId);
        pwsParties.setChildBankReferenceId(childBankRefId);
        pwsParties.setBeneficiaryChangeToken(beneChangeToken);
        collections.getParties().add(pwsParties);

        // Party Contact
        List<PwsPartyContacts> pwsPartyContactsList = new ArrayList<>();
        Optional.ofNullable(party.getPwsPartyContactList()).ifPresent(v -> {
            for (PwsPartyContacts pwsPartyContacts : v) {
                pwsPartyContacts.setTransactionId(txnId);
                pwsPartyContactsList.add(pwsPartyContacts);
            }
        });
        collections.getPartyContacts().add(pwsPartyContactsList);

        // Advise
        PwsTransactionAdvices pwsTransactionAdvices = creditTransfer.getAdvice();
        Optional.ofNullable(pwsTransactionAdvices).ifPresentOrElse(v -> {
            v.setTransactionId(txnId);
            v.setBankReferenceId(parentBankRefId);
            v.setChildBankReferenceId(childBankRefId);
            collections.getAdvices().add(v);
        }, () -> {
            collections.getAdvices().add(null);
        });

        // Tax
        List<PwsTaxInstructions> pwsTaxInstructionsList = new ArrayList<>();
        Optional.ofNullable(creditTransfer.getTaxInstructionList()).ifPresent(v -> {
            for (PwsTaxInstructions pwsTaxInstructions : v) {
                pwsTaxInstructions.setTransactionId(txnId);
                pwsTaxInstructions.setBankReferenceId(parentBankRefId);
                pwsTaxInstructions.setChildBankReferenceId(childBankRefId);
                pwsTaxInstructionsList.add(pwsTaxInstructions);
            }
        });
        collections.getTaxInstructions().add(pwsTaxInstructionsList);

    }
    private void executeBatchInsertsInOrder(TransactionBatchCollections collections, int batchNum) {
        log.info("Batch Insert: {}", batchNum);

        // 1. Insert Instructions
        log.info("Batch insert bulk transaction instructions ...");
        executeBatchInsert("insertPwsBulkTransactionInstructions", collections.getTxnInstructions(), null);

        // 2. Insert Parties
        log.info("Batch insert parties ...");
        List<PwsParties> pwsPartiesList = executeBatchInsertWithIds("insertPwsParties", collections.getParties());

        // 3. Insert PartyContacts
        List<PwsPartyContacts> partyContacts = new ArrayList<>();
        for (int i = 0; i < collections.getPartyContacts().size(); i++) {
            List<PwsPartyContacts> partyContactList = collections.getPartyContacts().get(i);
            long partyId = pwsPartiesList.get(i).getPartyId();
            for (PwsPartyContacts partyContact : partyContactList) {
                Optional.ofNullable(partyContact).ifPresent(v -> {
                    v.setPartyId(partyId);
                    partyContacts.add(v);
                });
            }
        }
        log.info("Batch insert party contacts ...");
        executeBatchInsert("insertPwsPartyContacts", partyContacts, null);

        // 4. Insert Advices
        List<PwsTransactionAdvices> advices = collections.getAdvices();
        for (int i = 0; i < advices.size(); i++) {
            long partyId = pwsPartiesList.get(i).getPartyId();
            Optional.ofNullable(advices.get(i)).ifPresent(v -> {
                v.setPartyId(partyId);
            });
        }
        List<PwsTransactionAdvices> noNullAdvices = advices.stream().filter(Objects::nonNull).toList();
        log.info("Batch insert advices ...");
        executeBatchInsert("insertPwsTransactionAdvices", noNullAdvices, null);

        // 5. Insert Taxes
        List<PwsTaxInstructions> txnInstructions = new ArrayList<>();
        for (int i = 0; i < collections.getTaxInstructions().size(); i++) {
            List<PwsTaxInstructions> txnInstructionList = collections.getTaxInstructions().get(i);
            for (PwsTaxInstructions txnInstruction : txnInstructionList) {
                Optional.ofNullable(txnInstruction).ifPresent(txnInstructions::add);
            }
        }
        log.info("Batch insert taxe instructions ...");
        executeBatchInsert("insertPwsTaxInstructions", txnInstructions, null);

    }

    private <T> void executeBatchInsert(String insertMethod, List<T> records, Consumer<List<T>> postBatchProcessor) {
        SqlSession session = paymentSaveSqlSessionTemplate.getSqlSessionFactory().openSession(ExecutorType.BATCH);
        List<T> processedRecords = new ArrayList<>();
        try {
            PwsSaveDao mapper = session.getMapper(PwsSaveDao.class);
            for (T record : records) {
                if (ObjectUtils.isEmpty(record)) {
                    continue;
                }
                Method method = mapper.getClass().getMethod(insertMethod, record.getClass());
                method.invoke(mapper, record);
                processedRecords.add(record);
            }
            session.flushStatements();
            if (postBatchProcessor != null) {
                postBatchProcessor.accept(processedRecords);
            }
            session.commit();
        } catch (Exception e) {
            session.rollback();
            throw new BulkProcessingException("Batch insert failed: " + insertMethod, e);
        } finally {
            session.close();
        }
    }

    private <T> List<T> executeBatchInsertWithIds(String insertMethod, List<T> records) {
        SqlSession session = paymentSaveSqlSessionTemplate.getSqlSessionFactory().openSession(ExecutorType.BATCH);
        List<T> processedRecords = new ArrayList<>();
        try {
            PwsSaveDao mapper = session.getMapper(PwsSaveDao.class);
            for (T record : records) {
                if (ObjectUtils.isEmpty(record)) {
                    continue;
                }
                Method method = mapper.getClass().getMethod(insertMethod, record.getClass());
                method.invoke(mapper, record);
                processedRecords.add(record);
            }
            session.flushStatements();
            session.commit();
            return processedRecords;
        } catch (Exception e) {
            session.rollback();
            throw new BulkProcessingException("Batch insert failed: " + insertMethod, e);
        } finally {
            session.close();
        }
    }

}
