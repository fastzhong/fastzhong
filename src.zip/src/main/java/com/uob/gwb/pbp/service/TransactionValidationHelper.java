package com.uob.gwb.pbp.service;

public interface TransactionValidationHelper {
}
