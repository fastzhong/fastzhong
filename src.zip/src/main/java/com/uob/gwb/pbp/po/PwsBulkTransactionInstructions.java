 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import java.math.BigDecimal;
import java.sql.Timestamp;
import lombok.Data;

@Data
public class PwsBulkTransactionInstructions {

    private long transactionInstructionsId;
    private String bankReferenceId;
    private String childBankReferenceId;
    private long transactionId;
    private long childTransactionInstructionsId;
    private Timestamp valueDate;
    private Timestamp settlementDate;
    private String paymentCodeId;
    private String paymentDetails;
    private String railCode;
    private String isRecurring;
    private String isPreApproved;
    private String customerReference;
    private String remarksForApproval;
    private String userComments;
    private String duplicationFlag;
    private String rejectCode;
    private String transactionCurrency;
    private BigDecimal transactionAmount;
    private String equivalentCurrency;
    private BigDecimal equivalentAmount;
    private String destinationCountry;
    private String destinationBankName;
    private String fxFlag;
    private String chargeOptions;
    private long transferSpeed;
    private Boolean isNew;
    private Boolean isBulkNew = Boolean.FALSE;
    private String bopPurposeCode;
    private String additionalPurposeCode;
    private String approvalCode;
    private String customerTransactionStatus;
    private String processingStatus;
    private String rejectReason;
    private Timestamp originalValueDate;
    private String dmpTransRef;
    private long childTemplateId;
    private Timestamp initiationTime;
    private String paymentCode;
}
