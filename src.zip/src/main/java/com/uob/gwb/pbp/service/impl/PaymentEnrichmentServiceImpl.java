 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.service.PaymentEnrichmentService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Slf4j
@Component
public class PaymentEnrichmentServiceImpl extends StepAwareService implements PaymentEnrichmentService {

    @Override
    public List<PaymentInformation> enrichPreValidation(List<PaymentInformation> paymentInfos) {
        // ToDo:
        // batchBooking?
        // paymentMethod
        return null;
    }

    @Override
    public List<PaymentInformation> enrichPostValidation(List<PaymentInformation> paymentInfos) {
        // ToDo:
        // PWS_TRANSACTIONS.TOTAL_CHILD
        // PWS_TRANSACTIONS.TOTAL_AMOUNT
        return null;
    }

    public List<CreditTransferTransaction> enrichCreditTransferTransactionPreValidation(
            List<CreditTransferTransaction> creditTransferTxns) {
        // ToDo:
        return null;
    }

    public List<CreditTransferTransaction> enrichCreditTransferTransactionPostValidation(
            List<CreditTransferTransaction> creditTransferTxns) {
        // ToDo:
        return null;
    }
}
