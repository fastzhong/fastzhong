 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.po.PwsTransactions;
import com.uob.gwb.pbp.service.PaymentEnrichmentService;
import java.math.BigDecimal;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("paymentEnrichmentService")
public class PaymentEnrichmentServiceImpl extends InboundStepAwareService implements PaymentEnrichmentService {

    @Override
    public List<PaymentInformation> enrichPreEntitlementValidation(List<PaymentInformation> paymentInfos) {
        // ToDo:
        return paymentInfos;
    }

    @Override
    public List<PaymentInformation> enrichPreTransactionValidation(List<PaymentInformation> paymentInfos) {
        // ToDo:
        // batchBooking?
        // paymentMethod
        return paymentInfos;
    }

    @Override
    public List<PaymentInformation> enrichPostTransactionValidation(List<PaymentInformation> paymentInfos) {
        // bulk payment computation
        for (PaymentInformation paymentInfo : paymentInfos) {
            if (!paymentInfo.isValid()) {
                continue;
            }

            int childTxnValidTotal = 0;
            BigDecimal childTxnValidAmount = BigDecimal.ZERO;
            BigDecimal childTxnMaxAmount = BigDecimal.ZERO;

            for (CreditTransferTransaction txn : paymentInfo.getCreditTransferTransactionList()) {
                if (!txn.isValid()) {
                    continue;
                }

                // for valid payment & valid txn
                BigDecimal txnAmount = txn.getPwsBulkTransactionInstructions().getTransactionAmount();

                childTxnValidTotal += 1;
                childTxnValidAmount = childTxnValidAmount.add(txnAmount);
                if (txnAmount.compareTo(childTxnMaxAmount) > 0) {
                    childTxnMaxAmount = txnAmount;
                }
            }

            PwsTransactions pwsTransactions = paymentInfo.getPwsTransactions();
            pwsTransactions.setTotalChild(childTxnValidTotal);
            pwsTransactions.setTotalAmount(childTxnValidAmount);
            pwsTransactions.setMaximumAmount(childTxnMaxAmount);
        }

        return paymentInfos;

    }

    @Override
    public List<PaymentInformation> enrichPostValidation(List<PaymentInformation> paymentInfos) {
        // ToDo:
        return paymentInfos;
    }

}
