 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.data.mapper;


import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.Party;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.DmpBulkStatus;
import com.uob.gwb.pbp.iso.pain001.CreditTransferTransactionInformationDTO;
import com.uob.gwb.pbp.iso.pain001.PaymentInformationDTO;
import com.uob.gwb.pbp.po.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Objects;
import org.apache.commons.codec.binary.Base64;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, imports = {OffsetDateTime.class,
        Instant.class, ZoneId.class, Date.class, ZoneOffset.class, SimpleDateFormat.class, Timestamp.class,
        Base64.class, String.class, LocalDateTime.class})
public interface Pain001ToBoMapper {


    @Mapping(target = "dmpBulkStatus", source = "bulkstatus", qualifiedByName = "mapBulkStatus")
    @Mapping(target = "pwsTransactions", source = ".")
    @Mapping(target = "pwsBulkTransactions", source = ".")
    @Mapping(target = "creditTransferTransactionList", source = "creditTransferTransactionInformation")
    PaymentInformation mapToPaymentInformation(PaymentInformationDTO paymentDTO);

    @Named("mapBulkStatus")
    default DmpBulkStatus mapBulkStatus(String bulkstatus) {
        return Objects.isNull(bulkstatus) ? null : DmpBulkStatus.fromValue(bulkstatus);
    }

    // PO: PwsTransactions
    @Named("mapPwsTransactions")
    @Mapping(target = "captureStatus", constant = "PENDING_SUBMIT")
    @Mapping(target = "customerTransactionStatus", constant = "NEW")
    @Mapping(target = "resourceId", source = "product")
    @Mapping(target = "featureId", source = "productfeature")
    @Mapping(target = "accountNumber", source = "debtorAccount.identification.other.identification")
    @Mapping(target = "accountCurrency", source = "debtorAccount.currency")
    PwsTransactions mapPwsTransactions(PaymentInformationDTO paymentDTO);


    @Named("mapPwsBulkTransactions")
    @Mapping(target = "dmpBatchNumber", source = "DMPBatchRef")
    PwsBulkTransactions mapPwsBulkTransactions(PaymentInformationDTO paymentDTO);

    @Named("mapCreditTransferTransaction")
    @Mapping(target = "pwsBulkTransactionInstructions", source = ".")
    @Mapping(target = "party", source = ".")
    @Mapping(target = "advice", source = ".")
    // @Mapping(target = "taxInstructionList", source = ".")
    CreditTransferTransaction mapCreditTransferTransaction(CreditTransferTransactionInformationDTO txnDTO);

    // PO: PwsBulkTransactionInstructions
    @Named("mapPwsBulkTransactionInstructions")
    @Mapping(target = "transactionAmount", source = "amount.instructedAmount.amount")
    @Mapping(target = "transactionCurrency", source = "amount.instructedAmount.currency")
    @Mapping(target = "destinationBankName", source = "creditorAgent.financialInstitutionIdentification.name")
    // @Mapping(target = "destinationCountry", source = "creditorAgent.financialInstitutionIdentification.postalAddress.country")
    PwsBulkTransactionInstructions mapPwsBulkTransactionInstructions(CreditTransferTransactionInformationDTO txnDTO);

    // PO: Party
    @Named("mapParty")
    // @Mapping(target = "pwsPartyContactList" source = "")
    Party mapParty(CreditTransferTransactionInformationDTO txnDTO);

    // PO: PwsParties
    @Named("mapPwsParties")
    @Mapping(target = "partyName", source = "creditTransferTransaction.creditor.name")
    // @Mapping(target = "swiftCode", source = "creditorAgent.financialInstitutionIdentification.BICFI")
    @Mapping(target = "partyAccountNumber", source = "creditorAccount.identification.other.identification")
    @Mapping(target = "residencyStatus", source = "supplementaryData.transactionInformationSupplement.creditorInformation.residentStatus")

    // @Mapping(target = "childBankReferenceId", source = "transactionReferenceId")
    // @Mapping(target = "bankReferenceId", source = "bankRefNumber")
    // @Mapping(target = "transactionId", source = "transactionId")
    // @Mapping(target = "idIssuingCountry", source =
    // "creditTransferTransaction.creditorAgent.financialInstitutionIdentification.postalAddress.country")
    // @Mapping(target = "beneficiaryChangeToken", expression =
    // "java(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().getEpochSecond())")
    PwsParties mapPwsParties(CreditTransferTransactionInformationDTO txnDTO);

    // ToDo: PO: Party Contacts
    // @Named("mapPwsPartyContacts")
    // PwsPartyContacts mapPwsPartyContacts(CreditTransferTransactionInformationDTO
    // txnDTO);

    // PO: PwsTransactionAdvices
    @Named("mapPwsTransactionAdvices")
    @Mapping(target = "adviceId", source = "creditor.identification.organisationIdentification.other.identification")
    PwsTransactionAdvices mapPwsTransactionAdvices(CreditTransferTransactionInformationDTO txnDTO);

    // ToDo: PO: PwsTaxInstructions
    @Named("mapPwsTaxInstructions")
    @Mapping(target = "taxableAmount", source = "tax.totalTaxableBaseAmount")
    @Mapping(target = "taxAmount", source = "tax.totalTaxAmount")
    //@Mapping(target = "taxSequenceNumber", source = "tax.sequenceNumber")
    //@Mapping(target = "taxPaymentCondition", source = "tax.record.type")
    //@Mapping(target = "typeOfIncome", source = "tax.record.category")
    //@Mapping(target = "taxDescription", source = "tax.record.categoryDetails")
    //@Mapping(target = "taxType", source = "tax.record.formsCode")
    @Mapping(target = "", source = "tax.record.taxAmount.rate")
    // @Mapping(target = "", source = "tax.record.taxAmount.taxableBaseAmount.amount")
    // @Mapping(target = "", source = "tax.record.taxAmount.taxableBaseAmount.currency")
    // @Mapping(target = "", source = "tax.record.taxAmount.totalAmount.amount")
    // @Mapping(target = "", source = "tax.record.taxAmount.totalAmount.currency")
    @Mapping(target = "vatAmount", source = "tax.record.additionalInformation")
    PwsTaxInstructions mapPwsTaxInstructions(CreditTransferTransactionInformationDTO txnDTO);

}
