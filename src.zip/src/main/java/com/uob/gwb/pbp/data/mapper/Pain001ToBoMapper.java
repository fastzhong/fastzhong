 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.data.mapper;


import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.DmpBulkStatus;
import com.uob.gwb.pbp.iso.pain001.CreditTransferTransactionInformationDTO;
import com.uob.gwb.pbp.iso.pain001.PaymentInformationDTO;
import com.uob.gwb.pbp.po.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Objects;
import org.apache.commons.codec.binary.Base64;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, imports = {OffsetDateTime.class,
        Instant.class, ZoneId.class, Date.class, ZoneOffset.class, SimpleDateFormat.class, Timestamp.class,
        Base64.class, String.class, LocalDateTime.class})
public interface Pain001ToBoMapper {

    // ToDo: https://confluencep.sg.uobnet.com/display/GBTCEW/BFU+Mapping+Overview
    // 19 paymentInformation.paymentInformationIdentification -
    // PWS_TRANSACTIONS_INSTRUCTIONS.CUSTOMER_REFERENCE?
    // 25 debtorName Debtor Name
    // DMP will provide? Initiator Company Name
    // customerCreditTransferInitiation.paymentInformation.debtor.name get from v3
    // api - Company Abbreviated name
    @Mapping(target = "dmpBulkStatus", source = "bulkstatus", qualifiedByName = "mapBulkStatus")
    @Mapping(target = "pwsTransactions", source = ".")
    @Mapping(target = "pwsBulkTransactions", source = ".")
    @Mapping(target = "creditTransferTransactionList", source = "creditTransferTransactionInformation")
    PaymentInformation mapToPaymentInformation(PaymentInformationDTO paymentDTO);

    @Named("mapBulkStatus")
    default DmpBulkStatus mapBulkStatus(String bulkstatus) {
        return Objects.isNull(bulkstatus) ? null : DmpBulkStatus.fromValue(bulkstatus);
    }

    // PO: PwsTransactions
    @Named("mapPwsTransactions")
    @Mapping(target = "changeToken", expression = "java(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())")
    @Mapping(target = "captureStatus", constant = "PENDING_SUBMIT")
    @Mapping(target = "customerTransactionStatus", constant = "NEW")
    // @Mapping(target = "resourceId", source = "")
    // @Mapping(target = "featureId", source = "")
    PwsTransactions mapPwsTransactions(PaymentInformationDTO paymentDTO);

    // PO: PwsBulkTransactions
    @Named("mapPwsBulkTransactions")
    @Mapping(target = "dmpBatchNumber", source = "dmpBatchRef")
    PwsBulkTransactions mapPwsBulkTransactions(PaymentInformationDTO paymentDTO);

    @Named("mapCreditTransferTransaction")
    @Mapping(target = "pwsBulkTransactionInstructions", source = ".")
    @Mapping(target = "party", source = ".")
    @Mapping(target = "partyBank", source = ".")
    @Mapping(target = "advice", source = ".")
    // @Mapping(target = "taxInstructionList", source = ".")
    CreditTransferTransaction mapCreditTransferTransaction(CreditTransferTransactionInformationDTO txnDTO);

    // PO: PwsBulkTransactionInstructions
    @Named("mapPwsBulkTransactionInstructions")
    @Mapping(target = "transactionCurrency", source = "txnDTO.amount.instructedAmount.currency")
    @Mapping(target = "destinationBankName", source = "txnDTO.creditorAgent.financialInstitutionIdentification.name")
    @Mapping(target = "destinationCountry", source = "txnDTO.creditorAgent.financialInstitutionIdentification.postalAddress.country")
    @Mapping(target = "customerReference", source = "txnDTO.paymentIdentification.endToEndIdentification")
    PwsBulkTransactionInstructions mapPwsBulkTransactionInstructions(CreditTransferTransactionInformationDTO txnDTO);

    // ToDo: PO: Party
    // @Named("mapParty")
    // @Mapping(target = "pwsPartyContactList")
    // Party mapParty(CreditTransferTransactionInformationDTO txnDTO);

    // ToDo: PO: PwsParties
    // @Named("mapPwsParties")
    // @Mapping(target = "partyName", source =
    // "creditTransferTransaction.creditor.name")
    // @Mapping(target = "accountNumber", source =
    // "creditTransferTransaction.creditorAccount.identification.other.identification")
    // @Mapping(target = "childBankReferenceId", source = "transactionReferenceId")
    // @Mapping(target = "bankReferenceId", source = "bankRefNumber")
    // @Mapping(target = "transactionId", source = "transactionId")
    // @Mapping(target = "idIssuingCountry", source =
    // "creditTransferTransaction.creditorAgent.financialInstitutionIdentification.postalAddress.country")
    // @Mapping(target = "beneficiaryChangeToken", expression =
    // "java(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().getEpochSecond())")
    // PwsParties mapPwsParties(CreditTransferTransactionInformationDTO txnDTO);

    // ToDo: PO: Party Contacts
    // @Named("mapPwsPartyContacts")
    // PwsPartyContacts mapPwsPartyContacts(CreditTransferTransactionInformationDTO
    // txnDTO);

    // ToDo: PO: PwsPartyBanks
    // @Named("mapPwsPartyBanks")
    // PwsPartyBanks mapPwsPartyBanks(CreditTransferTransactionInformationDTO
    // txnDTO);

    // ToDo: PO: PwsTransactionAdvices
    // @Named("mapPwsTransactionAdvices")
    // PwsTransactionAdvices
    // mapPwsTransactionAdvices(CreditTransferTransactionInformationDTO txnDTO);

    // ToDo: PO: PwsTaxInstructions
    // @Named("mapPwsTaxInstructions")
    // PwsTaxInstructions
    // mapPwsTaxInstructions(CreditTransferTransactionInformationDTO txnDTO);

}
