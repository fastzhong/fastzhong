 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.flow;

public class ContextKey {

    // route
    public final static String routeContext = "routeContext";

    // job
    public final static String routeName = "routeName";
    public final static String routeConfig = "routeConfig";
    public final static String country = "country";
    public final static String channel = "channel";
    public final static String bankEntity = "bankEntity";
    public final static String sourcePath = "sourcePath";
    public final static String sourceName = "sourceName";
    public final static String sourceFormat = "sourceFormat";

    public final static String result = "result";
    public final static String rejectOnError = "rejectOnError"; // reject on any validation error
    public final static String bankRefMetaData = "bankRefMetaData";
    public final static String fileUpload = "fileUpload";
    public final static String transitMessage = "transitMessage";
    public final static String paymentInformations = "paymentInformations";

}
