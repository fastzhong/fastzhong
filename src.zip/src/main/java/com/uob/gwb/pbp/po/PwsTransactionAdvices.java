 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.po;


import lombok.Data;

@Data
public class PwsTransactionAdvices {

    private String bankEntityId;
    private Long transactionId;
    private String bankReferenceId;
    private String childBankReferenceId;
    private Long partyId;
    private String adviceId;
    private String partyName1;
    private String partyName2;
    private String referenceNo;
    private String adviseMessage;
    private String deliveryMethod;
    private String deliveryAddress;
}
