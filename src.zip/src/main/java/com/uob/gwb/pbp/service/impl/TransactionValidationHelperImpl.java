package com.uob.gwb.pbp.service.impl;

import com.uob.gwb.pbp.service.TransactionValidationHelper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("transactionValidationHelper")
public class TransactionValidationHelperImpl implements TransactionValidationHelper {



}
