 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.bo;


import com.uob.gwb.pbp.bo.status.DmpTransactionStatus;
import com.uob.gwb.pbp.bo.validation.ValidationResult;
import com.uob.gwb.pbp.po.*;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class CreditTransferTransaction {

    List<ValidationResult> validationResults = new ArrayList<>();

    DmpTransactionStatus dmpTransactionStatus;

    // POs
    PwsBulkTransactionInstructions pwsBulkTransactionInstructions;
    Party party;
    PwsTransactionAdvices advice;
    List<PwsTaxInstructions> taxInstructionList; // 0-5 tax instructions

    public void addValidationError(String errorCode, String errorMsg) {
        validationResults.add(new ValidationResult(errorCode, errorMsg));
    }

    public boolean isValid() {
        if (DmpTransactionStatus.REJECTED.equals(dmpTransactionStatus)) {
            return false;
        }
        if (!validationResults.isEmpty()) {
            return false;
        }
        return true;
    }

}
