 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.flow;

public enum Pain001InboundProcessingStatus
{

    DmpRejected,
    SourceError, // source error before processing
    RejectOnError, // when RejectOnErrorSetting = true

    // 1. pain001 validation
    Processing,

    // 2. debulk
    DebulkPassed,

    // 3. entitlement & validation
    EntitlementPassed,
    EntitlementWithException,
    TransactionValidationPassed,
    TransactionValidationWithException,
    PostTransactionValidationPassed,
    PostTransactionValidationWithException,

    DuplicationPassed,
    DuplicationWithException,

    // 4. enrichment
    EnrichmentPassed,
    EnrichmentWithException,

    // 5. Save
    SavePassed,
    SaveWithException

}
