 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.service.PaymentDebulkService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service("paymentDebulkServiceImpl")
public class PaymentDebulkServiceImpl extends StepAwareService implements PaymentDebulkService {
    @Override
    public List<PaymentInformation> debulk(List<PaymentInformation> paymentInfos) {
        // no default debulk
        log.warn("no default debulk implementation");
        return paymentInfos;
    }

}
