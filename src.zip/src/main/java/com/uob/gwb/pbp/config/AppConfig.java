 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.config;


import com.uob.gwb.pbp.bo.Country;
import java.math.BigDecimal;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

@Data
@Slf4j
@Configuration
@ConfigurationProperties(prefix = "bulk-processing")

public class AppConfig {

    private Country country;

    private int batchInsertSize;

    private RetryConfig retry;

    private DebulkConfig debulk;

    @Bean
    public RetryTemplate retryTemplate() {
        log.info("retry config: {}", retry);

        RetryTemplate retryTemplate = new RetryTemplate();
        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(retry.getMaxAttempts());
        retryTemplate.setRetryPolicy(retryPolicy);
        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setInitialInterval(retry.getBackoff().getInitialInterval());
        backOffPolicy.setMultiplier(retry.getBackoff().getMultiplier());
        backOffPolicy.setMaxInterval(retry.getBackoff().getMaxInterval());
        return retryTemplate;
    }

    @Data
    public static class RetryConfig {
        private int maxAttempts;
        private BackoffProperties backoff = new BackoffProperties();

    }

    @Data
    public static class BackoffProperties {
        private long initialInterval;
        private double multiplier;
        private long maxInterval;
    }

    @Data
    public static class DebulkConfig {
        private String bankCode;
        private BigDecimal bahtnetThreshold;

    }

}
