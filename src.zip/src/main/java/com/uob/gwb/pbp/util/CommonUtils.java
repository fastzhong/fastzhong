 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.util;


import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.apache.commons.lang3.ObjectUtils;

public class CommonUtils {

    public static final DateFormat ISO_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public static final DateFormat ISO_DATETIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    static {
        ISO_DATE_FORMAT.setLenient(false);
        // ISO_DATE_TIME_FORMAT.setLenient(false);
    }

    // ToDo: handle datetimeString to date
    public static Date stringToDate(String s) throws ParseException {
        if (ObjectUtils.isNotEmpty(s)) {
            return new Date(ISO_DATE_FORMAT.parse(s).getTime());
        }
        // throw new ParseException("Can not convert null string to Date class", -1);
        return null;
    }

    // ToDo: handle dateString to timestamp
    public static Timestamp stringToTimestamp(String s) throws ParseException {
        if (ObjectUtils.isNotEmpty(s)) {
            return new Timestamp(ISO_DATETIME_FORMAT.parse(s).getTime());
        }
        // throw new ParseException("Can not convert null string to Date class", -1);
        return null;
    }

}
