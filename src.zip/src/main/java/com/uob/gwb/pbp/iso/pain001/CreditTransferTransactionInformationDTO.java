 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.iso.pain001;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class CreditTransferTransactionInformationDTO {
    @JsonProperty("DMPTransRef")
    private String dMPTransRef;
    @JsonProperty("transactionstatus")
    private String transactionstatus;
    @JsonProperty("errordescription")
    private String errordescription;
    @JsonProperty("linenumber")
    private String linenumber;
    @JsonProperty("product")
    private String product;
    @JsonProperty("paymentIdentification")
    private PaymentIdentificationDTO paymentIdentification;
    @JsonProperty("PaymentTypeInformation")
    private PaymentTypeInformationDTO paymentTypeInformation;
    @JsonProperty("amount")
    private AmountDTO amount;
    @JsonProperty("chargeBearer")
    private String chargeBearer;
    @JsonProperty("creditorAgent")
    private CreditorAgentDTO creditorAgent;
    @JsonProperty("creditor")
    private CreditorDTO creditor;
    @JsonProperty("creditorAccount")
    private CreditorAccountDTO creditorAccount;
    @JsonProperty("instructionForCreditorAgent")
    private List<InstructionForCreditorAgentDTO> instructionForCreditorAgent;
    @JsonProperty("tax")
    private TaxDTO tax;
    @JsonProperty("relatedRemittanceInformation")
    private List<RelatedRemittanceInformationDTO> relatedRemittanceInformation;
    @JsonProperty("remittanceInformation")
    private RemittanceInformationDTO remittanceInformation;
}
