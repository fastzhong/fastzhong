 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;


import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.dao.PwsDeleteDao;
import com.uob.gwb.pbp.service.PaymentDeleteService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@RequiredArgsConstructor
@Slf4j
@Service("paymentDeleteService")
public class PaymentDeleteServiceImpl extends InboundStepAwareService implements PaymentDeleteService {

    private final PwsDeleteDao pwsDeleteDao;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void deletePaymentInformation(PaymentInformation paymentInfo) {

        long txnId = paymentInfo.getPwsTransactions().getTransactionId();
        if (txnId != 0L) {
            pwsDeleteDao.deletePwsTaxInstructions(txnId);
            pwsDeleteDao.deletePwsTransactionAdvices(txnId);
            pwsDeleteDao.deletePwsPartyContacts(txnId);
            pwsDeleteDao.deletePwsParties(txnId);
            pwsDeleteDao.deletePwsBulkTransactionInstructions(txnId);
            pwsDeleteDao.deletePwsBulkTransactions(txnId);
            pwsDeleteDao.deletePwsTransactions(txnId);
        }

        paymentInfo.getPwsTransactions().setTransactionId(0L);
        paymentInfo.getPwsBulkTransactions().setTransactionId(0L);
        paymentInfo.getCreditTransferTransactionList().forEach(v -> v.getPwsBulkTransactionInstructions().setTransactionId(0L));
    }

}
