 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.flow;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.config.BulkRoutesConfig;
import com.uob.gwb.pbp.config.BulkRoutesConfig.ProcessingType;
import com.uob.gwb.pbp.config.BulkRoutesConfig.RouteConfig;
import com.uob.gwb.pbp.service.Pain001Service;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.tika.utils.StringUtils;
import org.springframework.batch.core.*;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.job.builder.SimpleJobBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class BulkProcessingFlowBuilder extends RouteBuilder {

    private final BulkRoutesConfig bulkRoutesConfig;
    private final ObjectMapper objMapper;
    private final JobRepository jobRepository;
    private final JobLauncher jobLauncher;
    private final PlatformTransactionManager platformTransactionManager;

    private final Pain001Service pain001Service;

    @Override
    public void configure() throws Exception {
        for (RouteConfig routeConfig : bulkRoutesConfig.getRoutes()) {
            if (routeConfig.isEnabled()) {
                configureRoute(routeConfig);
            }
        }
    }

    private void configureRoute(RouteConfig routeConfig) throws Exception {
        log.info("creating processing flow: {}", routeConfig.toString());
        if (routeConfig.getProcessingType() == ProcessingType.INBOUND) {
            // Inbound
            // ToDo: other exception
            onException(Exception.class).handled(true).process(exchange -> {
                Exception cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
                String fileName = exchange.getIn().getHeader(Exchange.FILE_NAME, String.class);
                log.error("Processing failed for file: {}. Error: {}", fileName, cause.getMessage(), cause);
                updateProcessingStatus(routeConfig, exchange, ProcessingStatus.FAILED);
            });
            // define the route
            from(buildInboundFromUri(routeConfig)).routeId(routeConfig.getRouteName())
                    .process(exchange -> prepareInboundContext(routeConfig, exchange))
                    .process(exchange -> {
                        // Create and run the batch job
                        JobParameters jobParameters = createInboundJobParameters(routeConfig, exchange);
                        Job job = createJob(routeConfig, exchange);
                        JobExecution jobExecution = jobLauncher.run(job, jobParameters);
                        handleInboundJobExecution(routeConfig, exchange, jobExecution);
                    });
        } else {
            // Outbound
            // ToDo: yet to implement
            throw new BulkProcessingException("flow type not supported",
                    new Throwable("Unsupported flow: " + routeConfig.getProcessingType()));
        }
    }

    private String buildInboundFromUri(RouteConfig routeConfig) {
        switch (routeConfig.getSourceType()) {
            case FILE :
                BulkRoutesConfig.FileSource f = routeConfig.getFileSource();
                String fileUri = "file:%s?antInclude=%s" + "&antExclude=%s" + "&charset=%s" + "&doneFileName=%s"
                        + "&delay=%d" + "&sortBy=%s" + "&maxMessagesPerPoll=%d" + "&noop=%b" + "&recursive=%b"
                        + "&move=%s" + "&moveFailed=%s" // This handles failed file movement automatically
                        + "&readLock=%s" + "&readLockTimeout=%d" + "&readLockLoggingLevel=%s";

                String uri = String.format(fileUri, f.getDirectoryName(), f.getAntInclude(), f.getAntExclude(),
                        f.getCharset(), f.getDoneFileName(), f.getDelay(), f.getSortBy(), f.getMaxMessagesPerPoll(),
                        f.isNoop(), f.isRecursive(), f.getMove(), f.getMoveFailed(), f.getReadLock(),
                        f.getReadLockTimeout(), f.getReadLockInterval());

                log.info("inboundFromUri: " + uri);
                return uri;
            default :
                log.error("Unsupported source type: {}", routeConfig.getSourceType());
                throw new BulkProcessingException("source type not supported",
                        new Throwable("Unsupported source type: " + routeConfig.getSourceType()));
        }
    }

    // Inbound Job
    private void prepareInboundContext(RouteConfig routeConfig, Exchange exchange) {
        // Create execution context with necessary data
        log.info("prepare inbound context ...");
        InboundContext routeContext = new InboundContext();
        routeContext.setRouteConfig(routeConfig);
        routeContext.setSourcePath(exchange.getIn().getHeader(Exchange.FILE_PATH, String.class));
        routeContext.setSourceName(exchange.getIn().getHeader(Exchange.FILE_NAME, String.class));
        routeContext.setFormat("json");
        // Clear the message body to free up memory
        exchange.getIn().setBody(null);
        LocalDateTime now = LocalDateTime.now();
        routeContext.setStart(now.atZone(ZoneId.systemDefault()) // timezone
                .toInstant()
                .toEpochMilli());
        exchange.setProperty("routeContext", routeContext);

        log.info("routeContext: {}", routeContext);
    }

    private JobParameters createInboundJobParameters(RouteConfig routeConfig, Exchange exchange) {
        log.info("create inbound job parameters ...");
        try {
            InboundContext routeContext = exchange.getProperty("routeContext", InboundContext.class);
            if (ObjectUtils.isEmpty(routeContext)) {
                throw new BulkProcessingException("routeContext is missing from Camel exchange",
                        new Throwable("routeContext is missing from Camel exchange"));
            }
            JobParameters params = new JobParametersBuilder().addString("routeName", routeConfig.getRouteName())
                    .addString("routeConfig", objMapper.writeValueAsString(routeConfig))
                    .addString("sourcePath", routeContext.getSourcePath())
                    .addString("sourceName", routeContext.getSourceName())
                    .toJobParameters();
            log.info("job parameters: {}", params);
            return params;
        } catch (JsonProcessingException e) {
            throw new BulkProcessingException("Error creating job parameters", e);
        }

    }

    private void handleInboundJobExecution(RouteConfig routeConfig, Exchange exchange, JobExecution jobExecution) {
        InboundContext routeContext = exchange.getProperty("routeContext", InboundContext.class);
        if (ObjectUtils.isEmpty(routeContext)) {
            throw new BulkProcessingException("routeContext is missing from Camel exchange",
                    new Throwable("routeContext is missing from Camel exchange"));
        }

        ProcessingStatus status = jobExecution.getStatus().equals(BatchStatus.COMPLETED)
                ? ProcessingStatus.SUCCESS
                : ProcessingStatus.FAILED;
        exchange.getIn().setHeader("processingStatus", status);
        if (ProcessingStatus.FAILED.equals(status)) {
            ExitStatus exitStatus = jobExecution.getExitStatus();
            String errorMessage = exitStatus.getExitDescription();
            routeContext.setErrorMsg(errorMessage);
        }

        if (jobExecution.getExecutionContext().containsKey("result")) {
            routeContext.setPain001InboundProcessingResult(
                    jobExecution.getExecutionContext().get("result", Pain001InboundProcessingResult.class));
            LocalDateTime now = LocalDateTime.now();
            routeContext.setEnd(now.atZone(ZoneId.systemDefault()) // timezone
                    .toInstant()
                    .toEpochMilli());
        }

        log.info("routeContext: {}", routeContext);
        updateProcessingStatus(routeConfig, exchange, status);
    }
    // Outbound Job
    private String buildOutboundToUri(RouteConfig routeConfig) {
        switch (routeConfig.getDestinationType()) {
            case FILE :
                BulkRoutesConfig.FileDestination f = routeConfig.getFileDestination();
                String fileUri = "file:%s?fileName=%s" + "&tempFileName=%s" + "&doneFileName=%s" + "&autoCreate=%b"
                        + "&fileExist=%s" + "&moveExisting=%s" + "&eagerDeleteTargetFile=%b" + "&delete=%b"
                        + "&chmod=%s";

                String uri = String.format(fileUri, f.getFileName(), f.getTempFileName(), f.getDoneFileName(),
                        f.isAutoCreate(), f.getFileExist(), f.getMoveExisting(), f.isEagerDeleteTargetFile(),
                        f.isDelete(), f.getChmod());

                log.info("outboundToUri: " + uri);
                return uri;
            default :
                log.error("Unsupported source type: {}", routeConfig.getSourceType());
                throw new BulkProcessingException("source type not supported",
                        new Throwable("Unsupported source type: " + routeConfig.getSourceType()));
        }
    }

    private void updateProcessingStatus(RouteConfig routeConfig, Exchange exchange, ProcessingStatus status) {
        // ToDo: update status
        // ToDo: notification
    }

    private Job createJob(RouteConfig routeConfig, Exchange exchange) {
        JobBuilder jobBuilder = new JobBuilder(routeConfig.getRouteName() + "Job", jobRepository);
        jobBuilder.listener(new JobExecutionListener() {
            @Override
            public void beforeJob(JobExecution jobExecution) {
                ExecutionContext executionContext = jobExecution.getExecutionContext();
                if (routeConfig.getProcessingType() == ProcessingType.INBOUND) {
                    // Inbound
                    InboundContext routeContext = exchange.getProperty("routeContext", InboundContext.class);
                    executionContext.put("routeConfig", routeConfig);
                    executionContext.put("sourcePath", routeContext.getSourcePath());
                    executionContext.put("sourceName", routeContext.getSourceName());
                    executionContext.put("result", new Pain001InboundProcessingResult());
                } else {
                    // ToDo: Outbound
                    throw new BulkProcessingException("flow type not supported",
                            new Throwable("Unsupported flow: " + routeConfig.getProcessingType()));
                }
                log.info("Job started successfully");
            }

            @Override
            public void afterJob(JobExecution jobExecution) {
                if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
                    log.info("Job completed successfully: {}", jobExecution.getJobInstance().getJobName());
                } else if (jobExecution.getStatus() == BatchStatus.FAILED) {
                    log.error("Job failed: {}", jobExecution.getJobInstance().getJobName());
                    log.error("errorMessage: {}", jobExecution.getExitStatus().getExitDescription());
                } else {
                    // ToDo: other cases for exception
                }
            }
        });

        List<String> stepNames = routeConfig.getSteps();
        if (stepNames == null || stepNames.isEmpty()) {
            throw new BulkProcessingException("No steps defined for route: " + routeConfig.getRouteName(),
                    new Throwable("no steps defined"));
        }

        Step firstStep = createStepForName(stepNames.get(0), routeConfig);
        SimpleJobBuilder simpleJobBuilder = jobBuilder.start(firstStep);

        for (int i = 1; i < stepNames.size(); i++) {
            Step step = createStepForName(stepNames.get(i), routeConfig);
            simpleJobBuilder.next(step);
        }

        return simpleJobBuilder.build();
    }

    private Step createStepForName(String stepName, RouteConfig routeConfig) {

        log.info("Creating step: {} for route: {}", stepName, routeConfig.getRouteName());

        StepBuilder stepBuilder = new StepBuilder(stepName, jobRepository);
        switch (stepName) {
            case "auth-validation" :
                return createPain001ValidationStep(stepBuilder, routeConfig);
            case "payment-debulk" :
                return createPaymentDebulkStep(stepBuilder, routeConfig);
            case "payment-validation" :
                return createPaymentValidationStep(stepBuilder, routeConfig);
            case "payment-enrichment" :
                return createPaymentEnrichmentStep(stepBuilder, routeConfig);
            case "payment-save" :
                return createPaymentSaveStep(stepBuilder, routeConfig);
            default :
                throw new BulkProcessingException("Unknown step: " + stepName, new Throwable("Unknown step"));
        }
    }

    // implement steps

    // pain001 file processing (tasklet)
    private Step createPain001ValidationStep(StepBuilder stepBuilder, RouteConfig routeConfig) {
        log.info("createPain001ValidationStep ...");
        return stepBuilder.tasklet((contribution, chunkContext) -> {
            ExecutionContext jobContext = chunkContext.getStepContext()
                    .getStepExecution()
                    .getJobExecution()
                    .getExecutionContext();

            pain001Service.beforeStep(chunkContext.getStepContext().getStepExecution());
            String sourcePath = Optional.ofNullable(jobContext.getString("sourcePath"))
                    .filter(v -> v.isEmpty())
                    .orElseThrow(() -> new BulkProcessingException("sourcePath is missing from job context",
                            new Throwable("sourcePath is missing from job context: "
                                    + chunkContext.getStepContext().getJobName())));
            String fileContent = Files.readString(Paths.get(sourcePath));
            if (StringUtils.isBlank(fileContent)) {
                throw new BulkProcessingException("File not found", new Throwable("File not found: " + sourcePath));
            }
            // convert to business objects for further processing
            List<PaymentInformation> paymentInformations = pain001Service.validateJson(fileContent);
            jobContext.put("paymentInformations", paymentInformations);

            return RepeatStatus.FINISHED;
        }, platformTransactionManager).build();
    }

    // createPaymentSplittingStep
    @SuppressWarnings("unchecked")
    private Step createPaymentDebulkStep(StepBuilder stepBuilder, RouteConfig routeConfig) {
        log.info("createPaymentDebulkStep ...");
        return stepBuilder.tasklet((contribution, chunkContext) -> {
            ExecutionContext jobContext = chunkContext.getStepContext()
                    .getStepExecution()
                    .getJobExecution()
                    .getExecutionContext();

            // debulk payment
            pain001Service.beforeStep(chunkContext.getStepContext().getStepExecution());
            List<PaymentInformation> paymentInfos = (List<PaymentInformation>) jobContext.get("paymentInformations");
            List<PaymentInformation> debulked = pain001Service.debulk(paymentInfos);
            jobContext.put("paymentInformations", debulked);

            return RepeatStatus.FINISHED;
        }, platformTransactionManager).build();
    }

    @SuppressWarnings("unchecked")
    private Step createPaymentValidationStep(StepBuilder stepBuilder, RouteConfig routeConfig) {
        log.info("createPaymentValidationStep ...");
        return stepBuilder.tasklet((contribution, chunkContext) -> {
            ExecutionContext jobContext = chunkContext.getStepContext()
                    .getStepExecution()
                    .getJobExecution()
                    .getExecutionContext();

            // validate payment
            pain001Service.beforeStep(chunkContext.getStepContext().getStepExecution());
            List<PaymentInformation> paymentInfos = (List<PaymentInformation>) jobContext.get("paymentInformations");
            List<PaymentInformation> validated = pain001Service.validate(paymentInfos);
            jobContext.put("paymentInformations", validated);

            return RepeatStatus.FINISHED;
        }, platformTransactionManager).build();
    }

    @SuppressWarnings("unchecked")
    private Step createPaymentEnrichmentStep(StepBuilder stepBuilder, RouteConfig routeConfig) {
        log.info("createPaymentEnrichmentStep ...");
        return stepBuilder.tasklet((contribution, chunkContext) -> {
            ExecutionContext jobContext = chunkContext.getStepContext()
                    .getStepExecution()
                    .getJobExecution()
                    .getExecutionContext();

            // enrich payment
            pain001Service.beforeStep(chunkContext.getStepContext().getStepExecution());
            List<PaymentInformation> paymentInfos = (List<PaymentInformation>) jobContext.get("paymentInformations");
            List<PaymentInformation> enriched = pain001Service.enrich(paymentInfos);
            jobContext.put("paymentInformations", enriched);

            return RepeatStatus.FINISHED;
        }, platformTransactionManager).build();
    }

    @SuppressWarnings("unchecked")
    private Step createPaymentSaveStep(StepBuilder stepBuilder, RouteConfig routeConfig) {
        log.info("createPaymentSaveStep ...");
        return stepBuilder.tasklet((contribution, chunkContext) -> {
            ExecutionContext jobContext = chunkContext.getStepContext()
                    .getStepExecution()
                    .getJobExecution()
                    .getExecutionContext();

            // save payment
            pain001Service.beforeStep(chunkContext.getStepContext().getStepExecution());
            List<PaymentInformation> paymentInfos = (List<PaymentInformation>) jobContext.get("paymentInformations");
            pain001Service.save(paymentInfos);

            return RepeatStatus.FINISHED;
        }, platformTransactionManager).build();
    }
}
