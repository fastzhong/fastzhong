 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.config;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.MatcherAssert.assertThat;

import com.google.code.beanmatchers.BeanMatchers;
import org.junit.jupiter.api.Test;

public class BulkRoutesConfigTest {

    @Test
    void testBulkRoutesConfig() {
        assertThat(BulkRoutesConfig.class,
                allOf(BeanMatchers.hasValidBeanConstructor(), BeanMatchers.hasValidGettersAndSetters()));
    }
}
