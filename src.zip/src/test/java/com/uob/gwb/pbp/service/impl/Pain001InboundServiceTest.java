 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.DmpBulkStatus;
import com.uob.gwb.pbp.data.mapper.Pain001ToBoMapper;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.flow.PwsSaveRecord;
import com.uob.gwb.pbp.po.PwsBulkTransactions;
import com.uob.gwb.pbp.po.PwsTransactions;
import com.uob.gwb.pbp.service.*;
import com.uob.gwb.pbp.util.PaymentUtils;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

@ExtendWith(MockitoExtension.class)
public class Pain001InboundServiceTest {

    @Mock
    private PaymentUtils paymentUtils;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private Pain001ToBoMapper pain001ToBoMapper;

    @Mock
    private PaymentMappingService pain001ToBo;

    @Mock
    private PaymentValidationService paymentInfoValidation;

    @Mock
    private PaymentEnrichmentService paymentInfoEnrichment;

    @Mock
    private PaymentDebulkService paymentDebulkService;

    @Mock
    private PaymentSaveService paymentSaveService;

    @InjectMocks
    private Pain001InboundServiceImpl pain001Service;

    @Mock
    protected StepExecution stepExecution;
    @Mock
    protected JobExecution jobExecution;
    private ExecutionContext stepContext;
    private ExecutionContext jobContext;

    private Pain001InboundProcessingResult result;
    private PwsSaveRecord mockRecord;

    @BeforeEach
    void setUp() {

        // Setup step execution context
        stepContext = new ExecutionContext();
        jobContext = new ExecutionContext();
        result = new Pain001InboundProcessingResult();
        jobContext.put("result", result);
        pain001Service.beforeStep(stepExecution);

        lenient().when(stepExecution.getExecutionContext()).thenReturn(stepContext);
        lenient().when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        lenient().when(jobExecution.getExecutionContext()).thenReturn(jobContext);
    }

    @Test
    void debulk_ShouldProcessAndUpdateResult() {
        List<PaymentInformation> inputPayments = Collections.singletonList(createValidPaymentInfo());
        List<PaymentInformation> debulkedPayments = Arrays.asList(createValidPaymentInfo(), createValidPaymentInfo());

        lenient().when(paymentDebulkService.debulk(inputPayments)).thenReturn(debulkedPayments);
        List<PaymentInformation> actualResult = pain001Service.debulk(inputPayments);

        // Assert
        verify(paymentDebulkService).beforeStep(stepExecution);
        verify(paymentDebulkService).debulk(inputPayments);
        assertEquals(debulkedPayments.size(), result.getPaymentDebulkTotal());
        assertEquals(debulkedPayments, actualResult);
    }

    @Test
    void save_WhenValidPayment_ShouldSaveSuccessfully() {
        PaymentInformation validPayment = createValidPaymentInfo();
        List<PaymentInformation> payments = Collections.singletonList(validPayment);

        pain001Service.save(payments);

        // Assert
        verify(paymentSaveService).savePaymentInformation(eq(validPayment));
        verifyNoMoreInteractions(paymentUtils);
    }

    @Test
    void save_WhenRejectedPayment_ShouldSkip() {
        PaymentInformation rejectedPayment = createRejectedPaymentInfo();
        List<PaymentInformation> payments = Collections.singletonList(rejectedPayment);

        pain001Service.save(payments);

        // Assert
        verify(paymentSaveService, never()).savePaymentInformation(eq(rejectedPayment));
    }
    @Test
    void save_WhenInvalidPayment_ShouldSkip() {
        PaymentInformation invalidPayment = createInvalidPaymentInfo();
        List<PaymentInformation> payments = Collections.singletonList(invalidPayment);

        pain001Service.save(payments);

        // Assert
        verify(paymentSaveService, never()).savePaymentInformation(eq(invalidPayment));
    }

    @Test
    void save_WhenSaveThrowsException_ShouldHandleError() {
        PaymentInformation validPayment = createValidPaymentInfo();
        List<PaymentInformation> payments = Collections.singletonList(validPayment);
        PwsSaveRecord saveRecord = new PwsSaveRecord(validPayment.getPwsTransactions().getTransactionId(),
                validPayment.getPwsBulkTransactions().getDmpBatchNumber());
        doThrow(new RuntimeException("Save failed")).when(paymentSaveService).savePaymentInformation(any());

        when(paymentUtils.createPwsSaveRecord(anyLong(), anyString())).thenReturn(saveRecord);

        pain001Service.save(payments);

        // Assert
        verify(paymentSaveService).savePaymentInformation(eq(validPayment));
        verify(paymentUtils).createPwsSaveRecord(validPayment.getPwsTransactions().getTransactionId(),
                validPayment.getPwsBulkTransactions().getDmpBatchNumber());
        verify(paymentUtils).updatePaymentSavedError(result, saveRecord);
    }

    // Helper methods
    private PaymentInformation createValidPaymentInfo() {
        PaymentInformation payment = new PaymentInformation();
        payment.setDmpBulkStatus(DmpBulkStatus.APPROVED);

        PwsTransactions pwsTransactions = new PwsTransactions();
        pwsTransactions.setTransactionId(1L);
        payment.setPwsTransactions(pwsTransactions);

        PwsBulkTransactions pwsBulkTransactions = new PwsBulkTransactions();
        pwsBulkTransactions.setDmpBatchNumber("BATCH001");
        payment.setPwsBulkTransactions(pwsBulkTransactions);

        return payment;
    }

    private PaymentInformation createRejectedPaymentInfo() {
        PaymentInformation payment = createValidPaymentInfo();
        payment.setDmpBulkStatus(DmpBulkStatus.REJECTED);
        return payment;
    }

    private PaymentInformation createInvalidPaymentInfo() {
        PaymentInformation payment = createValidPaymentInfo();
        return payment;
    }

}
