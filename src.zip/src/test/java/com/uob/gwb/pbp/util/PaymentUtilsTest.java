 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.flow.PwsSaveRecord;
import com.uob.gwb.transaction.common.util.TransactionUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PaymentUtilsTest {

    @Mock
    private TransactionUtils txnUtils;

    @InjectMocks
    private PaymentUtils paymentUtils;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreatePwsSaveRecord_WithValidIdAndDmpTxnRef() {
        long id = 123L;
        String dmpTxnRef = "dmpRef123";
        PwsSaveRecord record = paymentUtils.createPwsSaveRecord(id, dmpTxnRef);

        // Assert
        assertEquals(id, record.getTxnId());
        assertEquals(dmpTxnRef, record.getDmpTxnRef());
    }

    @Test
    void testCreatePwsSaveRecord_WithZeroId() {
        long id = 0;
        String dmpTxnRef = "dmpRef123";
        PwsSaveRecord record = paymentUtils.createPwsSaveRecord(id, dmpTxnRef);

        // Assert
        assertEquals(0, record.getTxnId());
        assertEquals(dmpTxnRef, record.getDmpTxnRef());
    }

    @Test
    void testCreatePwsSaveRecord_WithNullDmpTxnRef() {
        long id = 123L;
        PwsSaveRecord record = paymentUtils.createPwsSaveRecord(id, null);

        // Assert
        assertEquals(id, record.getTxnId());
        assertEquals("", record.getDmpTxnRef());
    }

    @Test
    void testUpdatePaymentSaved() {
        Pain001InboundProcessingResult result = new Pain001InboundProcessingResult();
        PwsSaveRecord record = new PwsSaveRecord(123L, "ref123");
        paymentUtils.updatePaymentSaved(result, record);

        // Assert
        assertTrue(result.getPaymentSaved().contains(record));
    }

    @Test
    void testUpdatePaymentSavedError_WhenRecordNotPresent() {
        Pain001InboundProcessingResult result = new Pain001InboundProcessingResult();
        PwsSaveRecord record = new PwsSaveRecord(123L, "ref123");
        paymentUtils.updatePaymentSavedError(result, record);

        // Assert
        assertTrue(result.getPaymentSavedError().contains(record));
    }

    @Test
    void testUpdatePaymentSavedError_WhenRecordAlreadyPresent() {
        Pain001InboundProcessingResult result = new Pain001InboundProcessingResult();
        PwsSaveRecord record = new PwsSaveRecord(123L, "ref123");
        result.getPaymentSavedError().add(record);
        paymentUtils.updatePaymentSavedError(result, record);

        // Assert
        assertEquals(1, result.getPaymentSavedError().size());
        assertTrue(result.getPaymentSavedError().contains(record));
    }
}
