package com.uob.gwb.pbp.config;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import javax.sql.DataSource;

@TestConfiguration
@Profile("test-th")
public class TestConfig {
    @Bean
    public DataSource defaultDataSource() {
        return new EmbeddedDatabaseBuilder()
                .setType(EmbeddedDatabaseType.H2)
                .addScript("classpath:/sql/schema-batch.sql")
                .addScript("classpath:/sql/schema-payment.sql")
                .build();
    }

    @Bean
    public DataSource paymentSaveDataSource() {
        return new EmbeddedDatabaseBuilder()
                .setType(EmbeddedDatabaseType.H2)
                .addScript("classpath:/sql/schema-payment.sql")
                .build();
    }

    @Bean
    public JdbcTemplate jdbcTemplate(DataSource paymentSaveDataSource) {
        return new JdbcTemplate(paymentSaveDataSource);
    }
}
