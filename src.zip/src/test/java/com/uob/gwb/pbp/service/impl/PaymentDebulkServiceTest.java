 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.Resource;
import com.uob.gwb.pbp.bo.status.DmpBulkStatus;
import com.uob.gwb.pbp.config.AppConfig;
import com.uob.gwb.pbp.po.PwsBulkTransactionInstructions;
import com.uob.gwb.pbp.po.PwsBulkTransactions;
import com.uob.gwb.pbp.po.PwsTransactions;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class PaymentDebulkServiceTest {

    @InjectMocks
    private PaymentDebulkServiceImplTH paymentDebulkService;

    private AppConfig appConfig;

    private static final String UOB_TH = "024";

    private static final BigDecimal AMOUNT_1M = new BigDecimal("1000000.00");
    private static final BigDecimal AMOUNT_2M = new BigDecimal("2000000.00");
    private static final BigDecimal AMOUNT_3M = new BigDecimal("3000000.00");

    @BeforeEach
    void init() {
        appConfig = new AppConfig();
        AppConfig.DebulkConfig debulkConfig = new AppConfig.DebulkConfig();
        debulkConfig.setBankCode(UOB_TH);
        debulkConfig.setBahtnetThreshold(AMOUNT_2M);
        appConfig.setDebulk(debulkConfig);
        ReflectionTestUtils.setField(paymentDebulkService, "appConfig", appConfig);
    }
    @Test
    void whenNoPayments_thenReturnEmptyList() {
        List<PaymentInformation> result = paymentDebulkService.debulk(Collections.emptyList());
        assertTrue(result.isEmpty());
    }

    @Test
    void whenPaymentIsRejected_thenReturnOriginalPayment() {
        PaymentInformation rejectedPayment = createPaymentInfo(Resource.SMART, AMOUNT_1M);
        rejectedPayment.setDmpBulkStatus(DmpBulkStatus.REJECTED);

        List<PaymentInformation> result = paymentDebulkService.debulk(Collections.singletonList(rejectedPayment));

        assertEquals(1, result.size());
    }

    @Test
    void whenNonSmartPayment_thenReturnOriginalPayment() {
        PaymentInformation nonSmartPayment = createPaymentInfo(Resource.IAFT, AMOUNT_1M);

        List<PaymentInformation> result = paymentDebulkService.debulk(Collections.singletonList(nonSmartPayment));

        assertEquals(1, result.size());
        assertEquals(Resource.IAFT.id, result.get(0).getPwsTransactions().getResourceId());
    }

    @Test
    void whenAllTransactionsUnder2M_thenAllSmartSameDay() {
        PaymentInformation payment = createPaymentInfo(Resource.SMART, AMOUNT_1M);
        addChildTransactions(payment, AMOUNT_1M, AMOUNT_1M);

        List<PaymentInformation> result = paymentDebulkService.debulk(Collections.singletonList(payment));

        assertEquals(1, result.size());
        assertEquals(Resource.SMART_SAME_DAY.id, result.get(0).getPwsTransactions().getResourceId());
        assertEquals(2, result.get(0).getCreditTransferTransactionList().size());
    }

    @Test
    void whenAllTransactionsOver2M_thenAllBahtnet() {
        PaymentInformation payment = createPaymentInfo(Resource.SMART, AMOUNT_3M);
        addChildTransactions(payment, AMOUNT_3M, AMOUNT_3M);

        List<PaymentInformation> result = paymentDebulkService.debulk(Collections.singletonList(payment));

        assertEquals(1, result.size());
        assertEquals(Resource.BAHTNET.id, result.get(0).getPwsTransactions().getResourceId());
        assertEquals(2, result.get(0).getCreditTransferTransactionList().size());
    }

    @Test
    void whenMixedTransactions_thenSplitIntoTwoGroups() {
        PaymentInformation payment = createPaymentInfo(Resource.SMART, AMOUNT_3M.add(AMOUNT_1M));
        addChildTransactions(payment, AMOUNT_3M, AMOUNT_1M);

        List<PaymentInformation> result = paymentDebulkService.debulk(Collections.singletonList(payment));

        assertEquals(2, result.size());

        PaymentInformation bahtnetPayment = result.stream()
                .filter(p -> Resource.BAHTNET.id.equals(p.getPwsTransactions().getResourceId()))
                .findFirst()
                .orElseThrow();

        PaymentInformation smartPayment = result.stream()
                .filter(p -> Resource.SMART_SAME_DAY.id.equals(p.getPwsTransactions().getResourceId()))
                .findFirst()
                .orElseThrow();

        assertEquals(1, bahtnetPayment.getCreditTransferTransactionList().size());
        assertEquals(1, smartPayment.getCreditTransferTransactionList().size());
    }

    // Helper methods to create test data
    private PaymentInformation createPaymentInfo(Resource resource, BigDecimal amount) {
        PaymentInformation paymentInfo = new PaymentInformation();
        PwsTransactions pwsTransactions = new PwsTransactions();
        pwsTransactions.setTransactionId(1L);
        pwsTransactions.setResourceId(resource.id);
        pwsTransactions.setTransactionTotalAmount(amount);
        pwsTransactions.setInitiationTime(Timestamp.from(Instant.now()));
        pwsTransactions.setCompanyId(1L);

        paymentInfo.setPwsTransactions(pwsTransactions);
        paymentInfo.setPwsBulkTransactions(new PwsBulkTransactions());

        return paymentInfo;
    }

    private void addChildTransactions(PaymentInformation paymentInfo, BigDecimal... amounts) {
        List<CreditTransferTransaction> childTransactions = Arrays.stream(amounts)
                .map(this::createChildTransaction)
                .toList();

        paymentInfo.setCreditTransferTransactionList(childTransactions);
        paymentInfo.getPwsTransactions().setTotalChild(childTransactions.size());
    }

    private CreditTransferTransaction createChildTransaction(BigDecimal amount) {
        CreditTransferTransaction transaction = new CreditTransferTransaction();

        PwsBulkTransactionInstructions instructions = new PwsBulkTransactionInstructions();
        instructions.setTransactionAmount(amount);
        transaction.setPwsBulkTransactionInstructions(instructions);

        return transaction;
    }
}
