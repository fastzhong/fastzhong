 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.util;

import static com.uob.gwb.pbp.util.CommonUtils.ISO_DATE_FORMAT;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.text.ParseException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class CommonUtilsTest {

    @Test
    void testStringToDate_WithValidDate() throws Exception {
        String dateString = "2024-11-01";
        Date result = CommonUtils.stringToDate(dateString);
        assertEquals(ISO_DATE_FORMAT.parse(dateString), result);
    }

    @Test
    void testStringToDate_WithInvalidDate() {
        String invalidDateString = "20-24-11";
        assertThrows(ParseException.class, () -> CommonUtils.stringToDate(invalidDateString));

    }

    @Test
    void testStringToDate_WithNullDate() throws ParseException {
        assertNull(CommonUtils.stringToDate(null));

    }

}
