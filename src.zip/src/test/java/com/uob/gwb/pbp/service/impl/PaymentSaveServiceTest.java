 /*
 * Copyright (c) United Overseas Bank Limited Co.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * United Overseas Bank Limited Co. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with
 * United Overseas Bank Limited Co.
 */
package com.uob.gwb.pbp.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.uob.gwb.pbp.bo.BankRefMetaData;
import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.Party;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.DmpTransactionStatus;
import com.uob.gwb.pbp.config.AppConfig;
import com.uob.gwb.pbp.dao.PwsSaveDao;
import com.uob.gwb.pbp.flow.BulkProcessingException;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.flow.PwsSaveRecord;
import com.uob.gwb.pbp.po.PwsBulkTransactionInstructions;
import com.uob.gwb.pbp.po.PwsBulkTransactions;
import com.uob.gwb.pbp.po.PwsParties;
import com.uob.gwb.pbp.po.PwsTransactions;
import com.uob.gwb.pbp.util.PaymentUtils;
import com.uob.gwb.transaction.common.util.TransactionUtils;
import java.util.ArrayList;
import java.util.List;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.support.RetryTemplate;

@ExtendWith(MockitoExtension.class)
class PaymentSaveServiceTest {
    @Mock
    private AppConfig config;

    @Mock
    private RetryTemplate retryTemplate;
    @Mock
    private SqlSessionTemplate paymentSaveSqlSessionTemplate;

    @Mock
    private SqlSessionFactory sqlSessionFactory;

    @Mock
    private SqlSession sqlSession;

    @Mock
    private PwsSaveDao pwsSaveDao;

    @Mock
    private PaymentUtils paymentUtils;

    @Mock
    private TransactionUtils transactionUtils;

    @Mock
    protected StepExecution stepExecution;

    @Mock
    protected JobExecution jobExecution;

    @InjectMocks
    private PaymentSaveServiceImpl paymentSave;

    private PaymentInformation paymentInfo;

    private ExecutionContext stepContext;
    private ExecutionContext jobContext;

    private BankRefMetaData bankRefMetaData;
    private List<Integer> childTxnBatchBankRefSeq;
    private Pain001InboundProcessingResult result;
    private PwsSaveRecord mockRecord;

    @BeforeEach
    void setUp() {
        paymentInfo = new PaymentInformation();
        stepContext = new ExecutionContext();
        jobContext = new ExecutionContext();
        result = new Pain001InboundProcessingResult();
        jobContext.put("result", result);
        mockRecord = new PwsSaveRecord(123L, "dmpRef123");

        // Setup step
        lenient().when(stepExecution.getExecutionContext()).thenReturn(stepContext);
        lenient().when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        lenient().when(jobExecution.getExecutionContext()).thenReturn(jobContext);

        // Setup SQL Session behavior
        lenient().when(paymentSaveSqlSessionTemplate.getSqlSessionFactory()).thenReturn(sqlSessionFactory);
        lenient().when(sqlSessionFactory.openSession(ExecutorType.BATCH)).thenReturn(sqlSession);
        lenient().when(sqlSession.getMapper(PwsSaveDao.class)).thenReturn(pwsSaveDao);

        // Setup PaymentUtils behavior
        lenient().when(paymentUtils.createPwsSaveRecord(anyLong(), anyString())).thenReturn(mockRecord);
        lenient().doNothing().when(paymentUtils).updatePaymentSaved(any(), any());
        lenient().doNothing().when(paymentUtils).updatePaymentSavedError(any(), any());

        paymentSave.beforeStep(stepExecution);
        bankRefMetaData = new BankRefMetaData("TH", "I", "SE", "2411");
        paymentSave.setBankRefMetaData(bankRefMetaData);

    }

    @Test
    void savePaymentInformation_SuccessfulSave() {
        int batchSize = 2;
        when(config.getBatchInsertSize()).thenReturn(batchSize);
        setupValidPaymentInfo(batchSize);
        setupSuccessfulBulkSave();
        setupChildTxnBatchBankRefSeq(batchSize);
        // Setup Retry
        when(retryTemplate.execute(any(RetryCallback.class), any(RecoveryCallback.class))).thenAnswer(invocation -> {
            RetryCallback<Object, RuntimeException> callback = invocation.getArgument(0);
            return callback.doWithRetry(null);
        });
        paymentSave.savePaymentInformation(paymentInfo);

        verify(paymentUtils).createPwsSaveRecord(eq(paymentInfo.getPwsTransactions().getTransactionId()),
                eq(paymentInfo.getPwsBulkTransactions().getDmpBatchNumber()));
        verify(paymentUtils).updatePaymentSaved(eq(result), eq(mockRecord));
        verify(pwsSaveDao).insertPwsTransactions(any(PwsTransactions.class));
        verify(pwsSaveDao).insertPwsBulkTransactions(any(PwsBulkTransactions.class));
        verifyBatchInsertsCalled();
    }

    @Test
    void savePaymentInformation_FailedBatchSave() {
        int batchSize = 2;
        when(config.getBatchInsertSize()).thenReturn(batchSize);
        setupValidPaymentInfo(batchSize);
        setupSuccessfulBulkSave();
        // setupChildTxnBatchBankRefSeq(batchSize);
        // Setup Retry
        when(retryTemplate.execute(any(RetryCallback.class), any(RecoveryCallback.class))).thenAnswer(invocation -> {
            throw new BulkProcessingException("Failed to insert", new RuntimeException());
        });
        paymentSave.savePaymentInformation(paymentInfo);

        // Assert
        verify(paymentUtils).updatePaymentSavedError(eq(result), eq(mockRecord));
        // verify(sqlSession, times(1)).rollback();
    }

    @Test
    void saveBulkPayment_Success() {
        int batchSize = 1;
        setupValidPaymentInfo(batchSize);
        setupSuccessfulBulkSave();
        long txnId = paymentSave.saveBulkPayment(paymentInfo);

        // Assert
        assertEquals(1L, txnId);
        verify(pwsSaveDao).getBankRefSequenceNum();
        verify(pwsSaveDao).insertPwsTransactions(any(PwsTransactions.class));
        verify(pwsSaveDao).insertPwsBulkTransactions(any(PwsBulkTransactions.class));
    }

    private void setupValidPaymentInfo(int size) {
        PwsTransactions pwsTransactions = new PwsTransactions();
        pwsTransactions.setTransactionId(1L);

        PwsBulkTransactions pwsBulkTransactions = new PwsBulkTransactions();
        pwsBulkTransactions.setDmpBatchNumber("BATCH001");

        List<CreditTransferTransaction> transactions = new ArrayList<>();
        for (int i = 1; i <= size; i++) {
            transactions.add(createValidTransaction(i));
        }

        paymentInfo.setPwsTransactions(pwsTransactions);
        paymentInfo.setPwsBulkTransactions(pwsBulkTransactions);
        paymentInfo.setCreditTransferTransactionList(transactions);
    }

    private CreditTransferTransaction createValidTransaction(int id) {
        CreditTransferTransaction transaction = new CreditTransferTransaction();
        transaction.setDmpTransactionStatus(DmpTransactionStatus.APPROVED);

        PwsBulkTransactionInstructions instructions = new PwsBulkTransactionInstructions();
        Party party = new Party();
        PwsParties pwsParties = new PwsParties();
        pwsParties.setPartyId((long) id);
        party.setPwsParties(pwsParties);

        transaction.setPwsBulkTransactionInstructions(instructions);
        transaction.setParty(party);

        return transaction;
    }

    private void setupSuccessfulBulkSave() {
        when(pwsSaveDao.getBankRefSequenceNum()).thenReturn(1);
        when(pwsSaveDao.insertPwsTransactions(any())).thenReturn(1);
        when(pwsSaveDao.insertPwsBulkTransactions(any())).thenReturn(1);
    }

    private void setupChildTxnBatchBankRefSeq(int size) {
        childTxnBatchBankRefSeq = new ArrayList<>();
        for (int i = 1; i <= size; i++) {
            childTxnBatchBankRefSeq.add(i);
        }
        when(pwsSaveDao.getBatchBankRefSequenceNum(size)).thenReturn(childTxnBatchBankRefSeq);
    }

    private void verifyBatchInsertsCalled() {
        verify(sqlSession, atLeastOnce()).commit();
        verify(sqlSession, never()).rollback();
        verify(sqlSession, atLeastOnce()).close();
    }
}
