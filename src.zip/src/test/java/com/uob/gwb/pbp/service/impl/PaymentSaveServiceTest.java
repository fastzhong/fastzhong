package com.uob.gwb.pbp.service.impl;

import com.uob.gwb.pbp.bo.CreditTransferTransaction;
import com.uob.gwb.pbp.bo.Party;
import com.uob.gwb.pbp.bo.PaymentInformation;
import com.uob.gwb.pbp.bo.status.DmpTransactionStatus;
import com.uob.gwb.pbp.config.AppConfig;
import com.uob.gwb.pbp.dao.PwsSaveDao;
import com.uob.gwb.pbp.flow.BulkProcessingException;
import com.uob.gwb.pbp.flow.Pain001InboundProcessingResult;
import com.uob.gwb.pbp.po.PwsBulkTransactionInstructions;
import com.uob.gwb.pbp.po.PwsBulkTransactions;
import com.uob.gwb.pbp.po.PwsParties;
import com.uob.gwb.pbp.po.PwsTransactions;
import com.uob.gwb.pbp.util.PaymentUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.support.RetryTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentSaveImplTest {

    @Mock
    private AppConfig config;

    @Mock
    private RetryTemplate retryTemplate;

    @Mock
    private SqlSessionTemplate paymentSaveSqlSessionTemplate;

    @Mock
    private SqlSessionFactory sqlSessionFactory;

    @Mock
    private SqlSession sqlSession;

    @Mock
    private PwsSaveDao pwsSaveDao;

    @Mock
    private PaymentUtils paymentUtils;

    @InjectMocks
    private PaymentSaveImpl paymentSave;

    private PaymentInformation paymentInfo;
    private ExecutionContext stepContext;
    private ExecutionContext jobContext;
    private Pain001InboundProcessingResult result;

    @BeforeEach
    void setUp() {
        paymentInfo = new PaymentInformation();
        stepContext = new ExecutionContext();
        jobContext = new ExecutionContext();
        result = new Pain001InboundProcessingResult();
        jobContext.put("result", result);

        // Setup SQL Session behavior
        when(paymentSaveSqlSessionTemplate.getSqlSessionFactory()).thenReturn(sqlSessionFactory);
        when(sqlSessionFactory.openSession(ExecutorType.BATCH)).thenReturn(sqlSession);
        when(sqlSession.getMapper(PwsSaveDao.class)).thenReturn(pwsSaveDao);
    }

    @Test
    void savePaymentInformation_SuccessfulSave() {
        int batchSize = 2;
        when(config.getBatchInsertSize()).thenReturn(batchSize);

        setupValidPaymentInfo();
        setupSuccessfulBulkSave();
        setupSuccessfulChildTransactionSave();

        paymentSave.savePaymentInformation(paymentInfo, stepContext, jobContext);

        verify(paymentUtils).createPwsSaveRecord(anyLong(), anyString());
        verify(paymentUtils).updatePaymentSaved(eq(result), any());
        verify(pwsSaveDao).insertPwsTransactions(any());
        verify(pwsSaveDao).insertPwsBulkTransactions(any());
        verifyBatchInsertsCalled();
    }

    @Test
    void savePaymentInformation_FailedBatchSave() {
        int batchSize = 2;
        when(config.getBatchInsertSize()).thenReturn(batchSize);

        setupValidPaymentInfo();
        setupSuccessfulBulkSave();
        setupFailedChildTransactionSave();

        paymentSave.savePaymentInformation(paymentInfo, stepContext, jobContext);

        verify(paymentUtils).createPwsSaveRecord(anyLong(), anyString());
        verify(paymentUtils).updatePaymentSavedError(eq(result), any());
        verify(sqlSession, times(1)).rollback();
    }

    @Test
    void saveBulkPayment_Success() {
        setupValidPaymentInfo();
        setupSuccessfulBulkSave();

        paymentSave.savePaymentInformation(paymentInfo, stepContext, jobContext);

        // Assert
        verify(pwsSaveDao).getBankRefSequenceNum();
        verify(pwsSaveDao).insertPwsTransactions(any());
        verify(pwsSaveDao).insertPwsBulkTransactions(any());
    }

    private void setupValidPaymentInfo() {
        PwsTransactions pwsTransactions = new PwsTransactions();
        pwsTransactions.setTransactionId(1L);

        PwsBulkTransactions pwsBulkTransactions = new PwsBulkTransactions();
        pwsBulkTransactions.setDmpBatchNumber("BATCH001");

        List<CreditTransferTransaction> transactions = new ArrayList<>();
        transactions.add(createValidTransaction());
        transactions.add(createValidTransaction());

        paymentInfo.setPwsTransactions(pwsTransactions);
        paymentInfo.setPwsBulkTransactions(pwsBulkTransactions);
        paymentInfo.setCreditTransferTransactionList(transactions);
    }

    private CreditTransferTransaction createValidTransaction() {
        CreditTransferTransaction transaction = new CreditTransferTransaction();
        transaction.setDmpTransactionStatus(DmpTransactionStatus.APPROVED);

        PwsBulkTransactionInstructions instructions = new PwsBulkTransactionInstructions();
        Party party = new Party();
        party.setPwsParties(new PwsParties());

        transaction.setPwsBulkTransactionInstructions(instructions);
        transaction.setParty(party);

        return transaction;
    }

    private void setupSuccessfulBulkSave() {
        when(pwsSaveDao.getBankRefSequenceNum()).thenReturn(1);
        when(pwsSaveDao.insertPwsTransactions(any())).thenReturn(1);
        when(pwsSaveDao.insertPwsBulkTransactions(any())).thenReturn(1);
    }

    private void setupSuccessfulChildTransactionSave() {
        doAnswer(invocation -> {
            RetryCallback<Object, RuntimeException> callback = invocation.getArgument(0);
            return callback.doWithRetry(null);
        }).when(retryTemplate).execute(any(RetryCallback.class), any(RecoveryCallback.class));
    }

    private void setupFailedChildTransactionSave() {
        doAnswer(invocation -> {
            throw new BulkProcessingException("Failed to insert", new RuntimeException());
        }).when(retryTemplate).execute(any(RetryCallback.class), any(RecoveryCallback.class));
    }

    private void verifyBatchInsertsCalled() {
        verify(sqlSession, atLeastOnce()).commit();
        verify(sqlSession, never()).rollback();
        verify(sqlSession, atLeastOnce()).close();
    }
}
